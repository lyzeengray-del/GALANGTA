package com.example

import android.view.KeyEvent
import com.example.model.KeyboardMouseConfig
import com.example.model.KeyboardMouseJsonCodec
import com.example.model.KeymapActionType
import com.example.model.MouseTweaksConfig
import com.example.model.defaultKeyboardMouseNodes
import com.example.shizuku.LvngKeyCodes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun linuxEvKeyMapping_mapsMouseKeyboardAndF1Correctly() {
    assertEquals(LvngKeyCodes.MOUSE_LEFT, LvngKeyCodes.linuxEvKeyToCanonical(0x110))
    assertEquals(LvngKeyCodes.MOUSE_RIGHT, LvngKeyCodes.linuxEvKeyToCanonical(0x111))
    assertEquals(LvngKeyCodes.MOUSE_SIDE_BACK, LvngKeyCodes.linuxEvKeyToCanonical(0x113))
    assertEquals(KeyEvent.KEYCODE_F1, LvngKeyCodes.linuxEvKeyToCanonical(59))
    assertEquals(KeyEvent.KEYCODE_W, LvngKeyCodes.linuxEvKeyToCanonical(17))
    assertEquals(KeyEvent.KEYCODE_A, LvngKeyCodes.linuxEvKeyToCanonical(30))
    assertEquals(KeyEvent.KEYCODE_S, LvngKeyCodes.linuxEvKeyToCanonical(31))
    assertEquals(KeyEvent.KEYCODE_D, LvngKeyCodes.linuxEvKeyToCanonical(32))
    assertEquals(KeyEvent.KEYCODE_SPACE, LvngKeyCodes.linuxEvKeyToCanonical(57))
    assertEquals(KeyEvent.KEYCODE_GRAVE, LvngKeyCodes.linuxEvKeyToCanonical(41))
  }

  @Test
  fun keyLabels_returnExpectedShortCodes() {
    assertEquals("LMB", LvngKeyCodes.shortLabel(LvngKeyCodes.MOUSE_LEFT))
    assertEquals("RMB", LvngKeyCodes.shortLabel(LvngKeyCodes.MOUSE_RIGHT))
    assertEquals("SPC", LvngKeyCodes.shortLabel(KeyEvent.KEYCODE_SPACE))
    assertEquals("F1", LvngKeyCodes.shortLabel(KeyEvent.KEYCODE_F1))
    assertEquals("?", LvngKeyCodes.shortLabel(KeyEvent.KEYCODE_UNKNOWN))
    assertTrue(LvngKeyCodes.isMouseCode(LvngKeyCodes.MOUSE_SCROLL_UP))
  }

  @Test
  fun defaultKeymapConfig_usesF1AndCleanEmptyCanvasWithAimPanEnum() {
    val cfg = KeyboardMouseConfig()
    assertTrue(defaultKeyboardMouseNodes().isEmpty())
    assertTrue(cfg.nodes.isEmpty())
    assertEquals(KeyEvent.KEYCODE_F1, MouseTweaksConfig().cursorToggleKeyCode)
    assertEquals(KeymapActionType.AIM_PAN, KeymapActionType.fromId("AIM_PAN"))
    assertEquals(KeymapActionType.MOUSE_AIM, KeymapActionType.fromId("MOUSE_AIM"))
  }

  @Test
  fun legacySchemaV1GraveToggleMigratesToF1() {
    assertEquals(
      KeyEvent.KEYCODE_F1,
      KeyboardMouseJsonCodec.resolveMigratedToggleKey(schemaVersion = 1, rawToggleKeyCode = KeyEvent.KEYCODE_GRAVE)
    )
    assertEquals(
      KeyEvent.KEYCODE_GRAVE,
      KeyboardMouseJsonCodec.resolveMigratedToggleKey(schemaVersion = 2, rawToggleKeyCode = KeyEvent.KEYCODE_GRAVE)
    )
  }
}
