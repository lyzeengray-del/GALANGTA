package com.example.input

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.example.model.KeymapActionType
import com.example.overlay.LvngRuntimeBus
import com.example.shizuku.LvngShizukuManager

/**
 * Fallback global hardware keyboard listener using AccessibilityService (`flagRequestFilterKeyEvents`).
 * Active on Android 11–16 devices whose SELinux rules block `shell` from opening `/dev/input/event*`
 * directly, ensuring OTG USB & Bluetooth keyboards still work reliably in all games and key binding.
 */
class LvngKeyboardBridgeService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnected = true
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = 0
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            notificationTimeout = 0L
        }
        LvngInputDeviceMonitor.refresh(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No UI scraping needed; solely acts as low-latency hardware key bridge.
    }

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_UNKNOWN ||
            code == KeyEvent.KEYCODE_BACK ||
            code == KeyEvent.KEYCODE_HOME ||
            code == KeyEvent.KEYCODE_APP_SWITCH ||
            code == KeyEvent.KEYCODE_VOLUME_UP ||
            code == KeyEvent.KEYCODE_VOLUME_DOWN ||
            code == KeyEvent.KEYCODE_VOLUME_MUTE ||
            code == KeyEvent.KEYCODE_POWER
        ) {
            return false
        }

        val action = event.action
        if (action != KeyEvent.ACTION_DOWN && action != KeyEvent.ACTION_UP) {
            return false
        }
        val isDown = action == KeyEvent.ACTION_DOWN
        if (isDown && event.repeatCount > 0) {
            // Avoid flooding Shizuku binder on key auto-repeat when a key is held
            return shouldConsumeDuringGameplay(code)
        }

        val busState = LvngRuntimeBus.state.value
        val kmStatus = LvngShizukuManager.keymapStatus.value
        val shouldForward = busState.isKeymapEditMode || busState.keyboardMouseConfig.isActive || kmStatus.isActive
        if (!shouldForward) return false

        // Always forward to keymap engine; engine performs per-key 90ms dedup against /dev/input/event*
        LvngShizukuManager.dispatchKeymapKeyEventAsync(code, isDown)

        return shouldConsumeDuringGameplay(code)
    }

    private fun shouldConsumeDuringGameplay(keyCode: Int): Boolean {
        val busState = LvngRuntimeBus.state.value
        if (busState.isKeymapEditMode) return false
        val cfg = busState.keyboardMouseConfig
        if (!cfg.isActive || cfg.nodes.isEmpty()) return false
        if (keyCode == cfg.tweaks.cursorToggleKeyCode ||
            (cfg.tweaks.cursorToggleKeyCode == KeyEvent.KEYCODE_F1 && keyCode == KeyEvent.KEYCODE_HELP)
        ) {
            return true
        }
        return cfg.nodes.any { node ->
            when (node.type) {
                KeymapActionType.WASD_JOYSTICK ->
                    keyCode == node.wasdUpKeyCode ||
                        keyCode == node.wasdLeftKeyCode ||
                        keyCode == node.wasdDownKeyCode ||
                        keyCode == node.wasdRightKeyCode
                KeymapActionType.KEY_TAP ->
                    node.keyCode != KeyEvent.KEYCODE_UNKNOWN && node.keyCode == keyCode
                KeymapActionType.MOUSE_AIM, KeymapActionType.AIM_PAN -> false
            }
        }
    }

    override fun onDestroy() {
        isServiceConnected = false
        LvngInputDeviceMonitor.refresh(this)
        super.onDestroy()
    }

    companion object {
        @Volatile
        var isServiceConnected: Boolean = false
            private set
    }
}
