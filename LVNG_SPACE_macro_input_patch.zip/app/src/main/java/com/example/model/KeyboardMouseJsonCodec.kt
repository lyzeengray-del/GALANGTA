package com.example.model

import org.json.JSONArray
import org.json.JSONObject

object KeyboardMouseJsonCodec {
    fun encode(config: KeyboardMouseConfig): JSONObject {
        val nodesArr = JSONArray()
        config.nodes.forEach { n ->
            nodesArr.put(
                JSONObject().apply {
                    put("id", n.id)
                    put("name", n.name)
                    put("type", n.type.id)
                    put("keyCode", n.keyCode)
                    put("x", n.xFraction.toDouble())
                    put("y", n.yFraction.toDouble())
                    put("radius", n.radiusFraction.toDouble())
                    put("behavior", n.triggerBehavior.id)
                    put("holdMs", n.holdTapDurationMs)
                    put("wasdUp", n.wasdUpKeyCode)
                    put("wasdLeft", n.wasdLeftKeyCode)
                    put("wasdDown", n.wasdDownKeyCode)
                    put("wasdRight", n.wasdRightKeyCode)
                }
            )
        }
        val t = config.tweaks
        val tweaksObj = JSONObject().apply {
            put("sensX", t.sensitivityX.toDouble())
            put("sensY", t.sensitivityY.toDouble())
            put("accel", t.acceleration.toDouble())
            put("smooth", t.smoothing.toDouble())
            put("deadzone", t.deadzonePx.toDouble())
            put("invertY", t.invertY)
            put("resetRadius", t.aimResetRadiusFraction.toDouble())
            put("toggleKey", t.cursorToggleKeyCode)
            put("autoLock", t.autoLockAimOnEnable)
            put("showHints", t.showKeyHintsOverlay)
            put("opacity", t.overlayOpacity.toDouble())
            put("aimPanInternalTweak", MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK)
        }
        return JSONObject().apply {
            put("schemaVersion", 2)
            put("active", config.isActive)
            put("nodes", nodesArr)
            put("tweaks", tweaksObj)
        }
    }

    fun encodeToString(config: KeyboardMouseConfig): String = encode(config).toString()

    fun encodeTemplateString(
        config: KeyboardMouseConfig,
        templateName: String = "LVNG SPACE Keymap"
    ): String {
        val t = config.tweaks
        val sb = StringBuilder(1024)
        sb.append("{\n")
        sb.append("  \"format\": \"lvng_keymap_template\",\n")
        sb.append("  \"app\": \"LVNG_SPACE\",\n")
        sb.append("  \"schemaVersion\": 2,\n")
        sb.append("  \"templateName\": ").append(jsonQuote(templateName)).append(",\n")
        sb.append("  \"exportedAtEpochMs\": ").append(System.currentTimeMillis()).append(",\n")
        sb.append("  \"active\": true,\n")
        sb.append("  \"nodes\": [\n")
        config.nodes.forEachIndexed { idx, n ->
            sb.append("    {\n")
            sb.append("      \"id\": ").append(jsonQuote(n.id)).append(",\n")
            sb.append("      \"name\": ").append(jsonQuote(n.name)).append(",\n")
            sb.append("      \"type\": ").append(jsonQuote(n.type.id)).append(",\n")
            sb.append("      \"keyCode\": ").append(n.keyCode).append(",\n")
            sb.append("      \"x\": ").append(n.xFraction.toDouble()).append(",\n")
            sb.append("      \"y\": ").append(n.yFraction.toDouble()).append(",\n")
            sb.append("      \"radius\": ").append(n.radiusFraction.toDouble()).append(",\n")
            sb.append("      \"behavior\": ").append(jsonQuote(n.triggerBehavior.id)).append(",\n")
            sb.append("      \"holdMs\": ").append(n.holdTapDurationMs).append(",\n")
            sb.append("      \"wasdUp\": ").append(n.wasdUpKeyCode).append(",\n")
            sb.append("      \"wasdLeft\": ").append(n.wasdLeftKeyCode).append(",\n")
            sb.append("      \"wasdDown\": ").append(n.wasdDownKeyCode).append(",\n")
            sb.append("      \"wasdRight\": ").append(n.wasdRightKeyCode).append('\n')
            sb.append(if (idx == config.nodes.lastIndex) "    }\n" else "    },\n")
        }
        sb.append("  ],\n")
        sb.append("  \"tweaks\": {\n")
        sb.append("    \"sensX\": ").append(t.sensitivityX.toDouble()).append(",\n")
        sb.append("    \"sensY\": ").append(t.sensitivityY.toDouble()).append(",\n")
        sb.append("    \"accel\": ").append(t.acceleration.toDouble()).append(",\n")
        sb.append("    \"smooth\": ").append(t.smoothing.toDouble()).append(",\n")
        sb.append("    \"deadzone\": ").append(t.deadzonePx.toDouble()).append(",\n")
        sb.append("    \"invertY\": ").append(t.invertY).append(",\n")
        sb.append("    \"resetRadius\": ").append(t.aimResetRadiusFraction.toDouble()).append(",\n")
        sb.append("    \"toggleKey\": ").append(t.cursorToggleKeyCode).append(",\n")
        sb.append("    \"autoLock\": ").append(t.autoLockAimOnEnable).append(",\n")
        sb.append("    \"showHints\": ").append(t.showKeyHintsOverlay).append(",\n")
        sb.append("    \"opacity\": ").append(t.overlayOpacity.toDouble()).append(",\n")
        sb.append("    \"aimPanInternalTweak\": ").append(MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK).append('\n')
        sb.append("  }\n")
        sb.append('}')
        return sb.toString()
    }

    fun encodeConfigRawJson(config: KeyboardMouseConfig, includeNewlines: Boolean = false): String {
        val t = config.tweaks
        val sep = if (includeNewlines) "\n" else ""
        val sb = StringBuilder(512)
        sb.append('{').append(sep)
        sb.append("\"schemaVersion\":2,").append(sep)
        sb.append("\"active\":").append(config.isActive).append(',').append(sep)
        sb.append("\"nodes\":[")
        config.nodes.forEachIndexed { idx, n ->
            sb.append('{')
            sb.append("\"id\":").append(jsonQuote(n.id)).append(',')
            sb.append("\"name\":").append(jsonQuote(n.name)).append(',')
            sb.append("\"type\":").append(jsonQuote(n.type.id)).append(',')
            sb.append("\"keyCode\":").append(n.keyCode).append(',')
            sb.append("\"x\":").append(n.xFraction.toDouble()).append(',')
            sb.append("\"y\":").append(n.yFraction.toDouble()).append(',')
            sb.append("\"radius\":").append(n.radiusFraction.toDouble()).append(',')
            sb.append("\"behavior\":").append(jsonQuote(n.triggerBehavior.id)).append(',')
            sb.append("\"holdMs\":").append(n.holdTapDurationMs).append(',')
            sb.append("\"wasdUp\":").append(n.wasdUpKeyCode).append(',')
            sb.append("\"wasdLeft\":").append(n.wasdLeftKeyCode).append(',')
            sb.append("\"wasdDown\":").append(n.wasdDownKeyCode).append(',')
            sb.append("\"wasdRight\":").append(n.wasdRightKeyCode)
            sb.append(if (idx == config.nodes.lastIndex) "}" else "},")
        }
        sb.append("],").append(sep)
        sb.append("\"tweaks\":{")
        sb.append("\"sensX\":").append(t.sensitivityX.toDouble()).append(',')
        sb.append("\"sensY\":").append(t.sensitivityY.toDouble()).append(',')
        sb.append("\"accel\":").append(t.acceleration.toDouble()).append(',')
        sb.append("\"smooth\":").append(t.smoothing.toDouble()).append(',')
        sb.append("\"deadzone\":").append(t.deadzonePx.toDouble()).append(',')
        sb.append("\"invertY\":").append(t.invertY).append(',')
        sb.append("\"resetRadius\":").append(t.aimResetRadiusFraction.toDouble()).append(',')
        sb.append("\"toggleKey\":").append(t.cursorToggleKeyCode).append(',')
        sb.append("\"autoLock\":").append(t.autoLockAimOnEnable).append(',')
        sb.append("\"showHints\":").append(t.showKeyHintsOverlay).append(',')
        sb.append("\"opacity\":").append(t.overlayOpacity.toDouble()).append(',')
        sb.append("\"aimPanInternalTweak\":").append(MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK)
        sb.append('}')
        sb.append('}')
        return sb.toString()
    }

    fun encodeProfilesToString(profiles: List<KeymapProfile>): String {
        val sb = StringBuilder(1024)
        sb.append("{\"profiles\":[")
        profiles.forEachIndexed { idx, p ->
            sb.append('{')
            sb.append("\"id\":").append(jsonQuote(p.id)).append(',')
            sb.append("\"name\":").append(jsonQuote(p.name)).append(',')
            sb.append("\"updatedAt\":").append(p.updatedAtMillis).append(',')
            sb.append("\"config\":").append(encodeConfigRawJson(p.config))
            sb.append(if (idx == profiles.lastIndex) "}" else "},")
        }
        sb.append("]}")
        return sb.toString()
    }

    @Suppress("UNCHECKED_CAST")
    fun decodeProfilesFromString(jsonStr: String?): List<KeymapProfile> {
        if (jsonStr.isNullOrBlank()) return emptyList()
        return runCatching {
            val root = PureJsonParser(jsonStr).parseRootObject()
            val arr = root["profiles"] as? List<*> ?: return@runCatching emptyList()
            arr.mapIndexedNotNull { idx, item ->
                val o = item as? Map<String, Any?> ?: return@mapIndexedNotNull null
                val id = o.optStr("id", "").ifBlank { "profile_${idx + 1}" }
                val name = o.optStr("name", "").ifBlank { "Profil ${idx + 1}" }
                val updatedAt = (o["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
                val cfgMap = o["config"] as? Map<String, Any?>
                val cfg = if (cfgMap != null) decodeConfigFromMap(cfgMap) else KeyboardMouseConfig()
                KeymapProfile(id = id, name = name, config = cfg, updatedAtMillis = updatedAt)
            }
        }.getOrElse { emptyList() }
    }

    @Suppress("UNCHECKED_CAST")
    fun decodeValidated(jsonStr: String?): Result<KeyboardMouseConfig> {
        if (jsonStr.isNullOrBlank()) {
            return Result.failure(IllegalArgumentException("File keymap kosong"))
        }
        return runCatching {
            val root = PureJsonParser(jsonStr).parseRootObject()
            val nodesRaw = root["nodes"] as? List<*>
                ?: throw IllegalArgumentException("Format salah: tombol ga ketemu")
            if (nodesRaw.isEmpty()) {
                throw IllegalArgumentException("File keymap masih kosong")
            }
            val decoded = decodeConfigFromMap(root, requireNodes = true, defaultActive = true)
            if (decoded.nodes.isEmpty()) {
                throw IllegalArgumentException("Ga ada tombol valid di file ini")
            }
            decoded
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun decodeConfigFromMap(
        root: Map<String, Any?>,
        requireNodes: Boolean = false,
        defaultActive: Boolean? = null
    ): KeyboardMouseConfig {
        val schemaVer = root.optInt("schemaVersion", 1)
        val nodesRaw = root["nodes"] as? List<*>
        val parsedNodes = if (nodesRaw != null) {
            nodesRaw.mapIndexedNotNull { i, item ->
                val o = item as? Map<String, Any?> ?: return@mapIndexedNotNull null
                val rawType = o.optStr("type", "")
                if (rawType.isBlank()) return@mapIndexedNotNull null
                val nodeId = o.optStr("id", "").ifBlank { "km_imp_${System.currentTimeMillis()}_${i + 1}" }
                KeyboardMouseNode(
                    id = nodeId,
                    name = o.optStr("name", "KEY ${i + 1}"),
                    type = KeymapActionType.fromId(rawType),
                    keyCode = o.optInt("keyCode", android.view.KeyEvent.KEYCODE_UNKNOWN),
                    xFraction = o.optDouble("x", 0.5).toFloat().coerceIn(0.02f, 0.98f),
                    yFraction = o.optDouble("y", 0.5).toFloat().coerceIn(0.03f, 0.97f),
                    radiusFraction = o.optDouble("radius", 0.095).toFloat().coerceIn(0.04f, 0.35f),
                    triggerBehavior = KeyTriggerBehavior.fromId(o.optStr("behavior", KeyTriggerBehavior.HOLD.id)),
                    holdTapDurationMs = o.optInt("holdMs", 45).coerceIn(15, 500),
                    wasdUpKeyCode = o.optInt("wasdUp", android.view.KeyEvent.KEYCODE_W),
                    wasdLeftKeyCode = o.optInt("wasdLeft", android.view.KeyEvent.KEYCODE_A),
                    wasdDownKeyCode = o.optInt("wasdDown", android.view.KeyEvent.KEYCODE_S),
                    wasdRightKeyCode = o.optInt("wasdRight", android.view.KeyEvent.KEYCODE_D)
                )
            }
        } else {
            emptyList()
        }
        if (requireNodes && parsedNodes.isEmpty()) {
            return KeyboardMouseConfig(nodes = emptyList(), isActive = false)
        }
        val t = root["tweaks"] as? Map<String, Any?>
        val tweaks = if (t != null) {
            val rawToggle = t.optInt("toggleKey", android.view.KeyEvent.KEYCODE_F1)
            val migratedToggle = resolveMigratedToggleKey(schemaVer, rawToggle)
            MouseTweaksConfig(
                sensitivityX = t.optDouble("sensX", 1.60).toFloat().coerceIn(0.1f, 10.0f),
                sensitivityY = t.optDouble("sensY", 1.40).toFloat().coerceIn(0.1f, 10.0f),
                acceleration = t.optDouble("accel", 0.0).toFloat().coerceIn(0f, 1.5f),
                smoothing = t.optDouble("smooth", 0.18).toFloat().coerceIn(0f, 0.85f),
                deadzonePx = t.optDouble("deadzone", 0.0).toFloat().coerceIn(0f, 5.0f),
                invertY = t.optBool("invertY", false),
                aimResetRadiusFraction = t.optDouble("resetRadius", 0.42).toFloat().coerceIn(0.10f, 0.48f),
                cursorToggleKeyCode = migratedToggle,
                autoLockAimOnEnable = t.optBool("autoLock", true),
                showKeyHintsOverlay = t.optBool("showHints", true),
                overlayOpacity = t.optDouble("opacity", 0.85).toFloat().coerceIn(0.15f, 1.0f),
                aimPanInternalTweak = MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK
            )
        } else {
            MouseTweaksConfig()
        }
        val isActive = defaultActive ?: root.optBool("active", false)
        return KeyboardMouseConfig(
            nodes = parsedNodes,
            tweaks = tweaks,
            isActive = isActive && parsedNodes.isNotEmpty()
        )
    }

    private fun jsonQuote(value: String): String {
        val sb = StringBuilder(value.length + 2)
        sb.append('"')
        for (ch in value) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (ch.code < 0x20) {
                    sb.append(String.format(java.util.Locale.US, "\\u%04x", ch.code))
                } else {
                    sb.append(ch)
                }
            }
        }
        sb.append('"')
        return sb.toString()
    }

    private fun Map<String, Any?>.optStr(key: String, default: String): String =
        (this[key] as? String) ?: default

    private fun Map<String, Any?>.optInt(key: String, default: Int): Int =
        (this[key] as? Number)?.toInt() ?: default

    private fun Map<String, Any?>.optDouble(key: String, default: Double): Double =
        (this[key] as? Number)?.toDouble() ?: default

    private fun Map<String, Any?>.optBool(key: String, default: Boolean): Boolean =
        (this[key] as? Boolean) ?: default

    private class PureJsonParser(private val src: String) {
        private var pos = 0

        @Suppress("UNCHECKED_CAST")
        fun parseRootObject(): Map<String, Any?> {
            skipWs()
            val obj = parseValue() as? Map<String, Any?>
                ?: throw IllegalArgumentException("Format file bukan JSON keymapping")
            skipWs()
            if (pos != src.length) {
                throw IllegalArgumentException("Karakter tidak valid setelah akhir JSON")
            }
            return obj
        }

        private fun skipWs() {
            while (pos < src.length && src[pos].isWhitespace()) pos++
        }

        private fun parseValue(): Any? {
            skipWs()
            if (pos >= src.length) throw IllegalArgumentException("JSON tidak lengkap")
            return when (src[pos]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> parseString()
                't', 'f' -> parseBoolean()
                'n' -> parseNull()
                '-', in '0'..'9' -> parseNumber()
                else -> throw IllegalArgumentException("Token JSON tidak valid di posisi $pos")
            }
        }

        private fun parseObject(): Map<String, Any?> {
            pos++ // '{'
            val map = LinkedHashMap<String, Any?>()
            skipWs()
            if (pos < src.length && src[pos] == '}') {
                pos++
                return map
            }
            while (true) {
                skipWs()
                if (pos >= src.length || src[pos] != '"') {
                    throw IllegalArgumentException("Kunci objek JSON tidak valid")
                }
                val key = parseString()
                skipWs()
                if (pos >= src.length || src[pos] != ':') {
                    throw IllegalArgumentException("Diharapkan ':' pada objek JSON")
                }
                pos++
                map[key] = parseValue()
                skipWs()
                if (pos >= src.length) throw IllegalArgumentException("Objek JSON belum ditutup")
                when (src[pos]) {
                    ',' -> pos++
                    '}' -> {
                        pos++
                        return map
                    }
                    else -> throw IllegalArgumentException("Diharapkan ',' atau '}' pada objek JSON")
                }
            }
        }

        private fun parseArray(): List<Any?> {
            pos++ // '['
            val list = ArrayList<Any?>()
            skipWs()
            if (pos < src.length && src[pos] == ']') {
                pos++
                return list
            }
            while (true) {
                list.add(parseValue())
                skipWs()
                if (pos >= src.length) throw IllegalArgumentException("Array JSON belum ditutup")
                when (src[pos]) {
                    ',' -> pos++
                    ']' -> {
                        pos++
                        return list
                    }
                    else -> throw IllegalArgumentException("Diharapkan ',' atau ']' pada array JSON")
                }
            }
        }

        private fun parseString(): String {
            pos++ // '"'
            val sb = StringBuilder()
            while (pos < src.length) {
                val ch = src[pos++]
                when (ch) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (pos >= src.length) throw IllegalArgumentException("Escape string JSON tidak lengkap")
                        when (val esc = src[pos++]) {
                            '"', '\\', '/' -> sb.append(esc)
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > src.length) throw IllegalArgumentException("Unicode escape tidak lengkap")
                                val hex = src.substring(pos, pos + 4)
                                sb.append(hex.toInt(16).toChar())
                                pos += 4
                            }
                            else -> throw IllegalArgumentException("Escape JSON tidak dikenal: \\$esc")
                        }
                    }
                    else -> sb.append(ch)
                }
            }
            throw IllegalArgumentException("String JSON belum ditutup")
        }

        private fun parseBoolean(): Boolean {
            return if (src.startsWith("true", pos)) {
                pos += 4
                true
            } else if (src.startsWith("false", pos)) {
                pos += 5
                false
            } else {
                throw IllegalArgumentException("Boolean JSON tidak valid")
            }
        }

        private fun parseNull(): Any? {
            if (src.startsWith("null", pos)) {
                pos += 4
                return null
            }
            throw IllegalArgumentException("Nilai null JSON tidak valid")
        }

        private fun parseNumber(): Number {
            val start = pos
            if (src[pos] == '-') pos++
            while (pos < src.length && src[pos].isDigit()) pos++
            var isFloat = false
            if (pos < src.length && src[pos] == '.') {
                isFloat = true
                pos++
                while (pos < src.length && src[pos].isDigit()) pos++
            }
            if (pos < src.length && (src[pos] == 'e' || src[pos] == 'E')) {
                isFloat = true
                pos++
                if (pos < src.length && (src[pos] == '+' || src[pos] == '-')) pos++
                while (pos < src.length && src[pos].isDigit()) pos++
            }
            val raw = src.substring(start, pos)
            return if (isFloat) raw.toDouble() else raw.toLongOrNull() ?: raw.toDouble()
        }
    }

    fun decode(jsonStr: String?): KeyboardMouseConfig {
        if (jsonStr.isNullOrBlank()) return KeyboardMouseConfig()
        return runCatching {
            val root = JSONObject(jsonStr)
            val schemaVer = root.optInt("schemaVersion", 1)
            val nodesArr = root.optJSONArray("nodes")
            val nodes = if (nodesArr != null) {
                (0 until nodesArr.length()).mapNotNull { i ->
                    val o = nodesArr.optJSONObject(i) ?: return@mapNotNull null
                    KeyboardMouseNode(
                        id = o.optString("id", "km_${i + 1}"),
                        name = o.optString("name", "KEY ${i + 1}"),
                        type = KeymapActionType.fromId(o.optString("type", KeymapActionType.KEY_TAP.id)),
                        keyCode = o.optInt("keyCode", android.view.KeyEvent.KEYCODE_UNKNOWN),
                        xFraction = o.optDouble("x", 0.5).toFloat().coerceIn(0.02f, 0.98f),
                        yFraction = o.optDouble("y", 0.5).toFloat().coerceIn(0.03f, 0.97f),
                        radiusFraction = o.optDouble("radius", 0.095).toFloat().coerceIn(0.04f, 0.35f),
                        triggerBehavior = KeyTriggerBehavior.fromId(o.optString("behavior", KeyTriggerBehavior.HOLD.id)),
                        holdTapDurationMs = o.optInt("holdMs", 45).coerceIn(15, 500),
                        wasdUpKeyCode = o.optInt("wasdUp", android.view.KeyEvent.KEYCODE_W),
                        wasdLeftKeyCode = o.optInt("wasdLeft", android.view.KeyEvent.KEYCODE_A),
                        wasdDownKeyCode = o.optInt("wasdDown", android.view.KeyEvent.KEYCODE_S),
                        wasdRightKeyCode = o.optInt("wasdRight", android.view.KeyEvent.KEYCODE_D)
                    )
                }
            } else {
                defaultKeyboardMouseNodes()
            }

            val t = root.optJSONObject("tweaks")
            val tweaks = if (t != null) {
                val rawToggle = t.optInt("toggleKey", android.view.KeyEvent.KEYCODE_F1)
                val migratedToggle = resolveMigratedToggleKey(schemaVer, rawToggle)
                MouseTweaksConfig(
                    sensitivityX = t.optDouble("sensX", 1.60).toFloat().coerceIn(0.1f, 10.0f),
                    sensitivityY = t.optDouble("sensY", 1.40).toFloat().coerceIn(0.1f, 10.0f),
                    acceleration = t.optDouble("accel", 0.0).toFloat().coerceIn(0f, 1.5f),
                    smoothing = t.optDouble("smooth", 0.18).toFloat().coerceIn(0f, 0.85f),
                    deadzonePx = t.optDouble("deadzone", 0.0).toFloat().coerceIn(0f, 5.0f),
                    invertY = t.optBoolean("invertY", false),
                    aimResetRadiusFraction = t.optDouble("resetRadius", 0.42).toFloat().coerceIn(0.10f, 0.48f),
                    cursorToggleKeyCode = migratedToggle,
                    autoLockAimOnEnable = t.optBoolean("autoLock", true),
                    showKeyHintsOverlay = t.optBoolean("showHints", true),
                    overlayOpacity = t.optDouble("opacity", 0.85).toFloat().coerceIn(0.15f, 1.0f),
                    aimPanInternalTweak = MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK
                )
            } else {
                MouseTweaksConfig()
            }

            KeyboardMouseConfig(
                nodes = nodes,
                tweaks = tweaks,
                isActive = root.optBoolean("active", false)
            )
        }.getOrElse { KeyboardMouseConfig() }
    }

    internal fun resolveMigratedToggleKey(schemaVersion: Int, rawToggleKeyCode: Int): Int {
        return if (schemaVersion < 2 && rawToggleKeyCode == android.view.KeyEvent.KEYCODE_GRAVE) {
            android.view.KeyEvent.KEYCODE_F1
        } else {
            rawToggleKeyCode
        }
    }
}

object KeymapProfileHelper {
    fun ensureInitialized(
        profiles: List<KeymapProfile>,
        activeProfileId: String?,
        fallbackConfig: KeyboardMouseConfig
    ): Pair<List<KeymapProfile>, String> {
        val list = if (profiles.isEmpty()) {
            listOf(KeymapProfile.defaultProfile(fallbackConfig))
        } else {
            profiles
        }
        val resolvedId = if (!activeProfileId.isNullOrBlank() && list.any { it.id == activeProfileId }) {
            activeProfileId
        } else {
            list.first().id
        }
        return list to resolvedId
    }

    fun upsertConfig(
        profiles: List<KeymapProfile>,
        activeProfileId: String,
        config: KeyboardMouseConfig
    ): Pair<List<KeymapProfile>, String> {
        val (ensured, targetId) = ensureInitialized(profiles, activeProfileId, config)
        val now = System.currentTimeMillis()
        val updated = ensured.map { p ->
            if (p.id == targetId) p.copy(config = config, updatedAtMillis = now) else p
        }
        return updated to targetId
    }

    fun createProfile(
        profiles: List<KeymapProfile>,
        name: String,
        seedConfig: KeyboardMouseConfig
    ): Pair<List<KeymapProfile>, KeymapProfile> {
        val (ensured, _) = ensureInitialized(profiles, null, seedConfig)
        val cleanName = name.trim().take(20).ifBlank { "Profil ${ensured.size + 1}" }
        val newProfile = KeymapProfile(
            id = "profile_${System.currentTimeMillis()}_${ensured.size + 1}",
            name = cleanName,
            config = seedConfig
        )
        return (ensured + newProfile) to newProfile
    }

    fun renameProfile(
        profiles: List<KeymapProfile>,
        profileId: String,
        newName: String
    ): List<KeymapProfile> {
        val clean = newName.trim().take(20)
        if (clean.isBlank()) return profiles
        return profiles.map { if (it.id == profileId) it.copy(name = clean) else it }
    }

    fun deleteProfile(
        profiles: List<KeymapProfile>,
        profileId: String,
        currentActiveId: String
    ): Triple<List<KeymapProfile>, String, KeyboardMouseConfig> {
        if (profiles.size <= 1) {
            val sole = profiles.firstOrNull() ?: KeymapProfile.defaultProfile()
            return Triple(listOf(sole), sole.id, sole.config)
        }
        val remaining = profiles.filterNot { it.id == profileId }
        val safeList = if (remaining.isEmpty()) listOf(KeymapProfile.defaultProfile()) else remaining
        val nextActive = if (currentActiveId == profileId) safeList.first() else {
            safeList.firstOrNull { it.id == currentActiveId } ?: safeList.first()
        }
        return Triple(safeList, nextActive.id, nextActive.config)
    }
}
