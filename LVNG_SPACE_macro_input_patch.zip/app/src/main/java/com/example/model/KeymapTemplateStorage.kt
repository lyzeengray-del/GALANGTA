package com.example.model

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class KeymapExportResult(
    val success: Boolean,
    val fileName: String,
    val savedDisplayPath: String? = null,
    val shareUri: Uri? = null,
    val needsSaveAsPicker: Boolean = false,
    val errorMessage: String? = null
)

object KeymapTemplateStorage {
    private const val MAX_IMPORT_BYTES = 1_048_576 // 1 MB safety cap

    fun buildDefaultFileName(prefix: String = "lvng_keymap"): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${prefix}_$stamp.json"
    }

    /**
     * Automatically creates a portable `.json` keymapping template file.
     * - Always writes a FileProvider shareable copy inside cacheDir/shared_keymaps/.
     * - On Android 10+ (API 29+), also writes directly into Download/LVNG_SPACE/<fileName>
     *   via MediaStore without requiring any legacy storage permission.
     * - On Android 9 and below, sets [KeymapExportResult.needsSaveAsPicker] = true so the UI can
     *   optionally launch SAF CreateDocument in addition to offering instant share.
     */
    fun exportAutomatically(
        context: Context,
        config: KeyboardMouseConfig,
        templateName: String = "LVNG SPACE Keymap"
    ): KeymapExportResult {
        if (config.nodes.isEmpty()) {
            return KeymapExportResult(
                success = false,
                fileName = "",
                errorMessage = "Belum ada tombol buat diexport"
            )
        }
        val fileName = buildDefaultFileName()
        val jsonText = KeyboardMouseJsonCodec.encodeTemplateString(config, templateName)

        val shareUri = runCatching {
            val dir = File(context.cacheDir, "shared_keymaps").apply { mkdirs() }
            // Keep cache tidy (max 10 latest exports)
            dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(10)?.forEach {
                runCatching { it.delete() }
            }
            val outFile = File(dir, fileName)
            outFile.writeText(jsonText, Charsets.UTF_8)
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
        }.getOrNull()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val downloadSaved = runCatching {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/json")
                    put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        "${Environment.DIRECTORY_DOWNLOADS}/LVNG_SPACE"
                    )
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Gagal bikin file di Download")
                resolver.openOutputStream(itemUri)?.use { out ->
                    out.write(jsonText.toByteArray(Charsets.UTF_8))
                } ?: error("Gagal nulis file")
                val doneValues = ContentValues().apply {
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }
                resolver.update(itemUri, doneValues, null, null)
                itemUri
            }
            if (downloadSaved.isSuccess) {
                return KeymapExportResult(
                    success = true,
                    fileName = fileName,
                    savedDisplayPath = "Download/LVNG_SPACE/$fileName",
                    shareUri = shareUri ?: downloadSaved.getOrNull(),
                    needsSaveAsPicker = false
                )
            }
        }

        return KeymapExportResult(
            success = shareUri != null,
            fileName = fileName,
            savedDisplayPath = null,
            shareUri = shareUri,
            needsSaveAsPicker = true,
            errorMessage = if (shareUri == null) "Gagal bikin file template" else null
        )
    }

    fun writeTemplateToUri(
        context: Context,
        uri: Uri,
        config: KeyboardMouseConfig,
        templateName: String = "LVNG SPACE Keymap"
    ): Result<Unit> = runCatching {
        val jsonText = KeyboardMouseJsonCodec.encodeTemplateString(config, templateName)
        context.contentResolver.openOutputStream(uri)?.use { out ->
            out.write(jsonText.toByteArray(Charsets.UTF_8))
        } ?: error("Gagal buka lokasi file")
    }

    fun readTemplateFromUri(context: Context, uri: Uri): Result<KeyboardMouseConfig> = runCatching {
        val raw = context.contentResolver.openInputStream(uri)?.use { input ->
            val bytes = input.readNBytes(MAX_IMPORT_BYTES)
            String(bytes, Charsets.UTF_8)
        } ?: error("Gagal baca file")
        KeyboardMouseJsonCodec.decodeValidated(raw).getOrThrow()
    }

    fun buildShareChooserIntent(context: Context, shareUri: Uri, fileName: String): Intent {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, shareUri)
            putExtra(Intent.EXTRA_SUBJECT, "Template Keymap LVNG SPACE ($fileName)")
            putExtra(
                Intent.EXTRA_TEXT,
                "Template keymap LVNG SPACE ($fileName). Import file .json ini di Keymap."
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(sendIntent, "Share Keymap (.json)").apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
