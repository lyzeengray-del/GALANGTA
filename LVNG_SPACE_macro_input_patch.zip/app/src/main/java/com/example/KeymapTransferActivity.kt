package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.example.data.LvngPreferencesRepository
import com.example.model.KeymapTemplateStorage
import com.example.overlay.LvngRuntimeBus
import com.example.shizuku.LvngShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Lightweight translucent Activity used by both in-app UI and Overlay Keymap Editor
 * to host system SAF OpenDocument / CreateDocument / Share Sheet without overlapping
 * TYPE_APPLICATION_OVERLAY windows.
 */
class KeymapTransferActivity : ComponentActivity() {

    private var dispatched = false

    private val openDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) {
            finish()
            return@registerForActivityResult
        }
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                KeymapTemplateStorage.readTemplateFromUri(applicationContext, uri)
            }
            result.onSuccess { imported ->
                val bus = LvngRuntimeBus.state.value
                val isEditMode = bus.isKeymapEditMode
                val (updatedProfiles, activeId) = com.example.model.KeymapProfileHelper.upsertConfig(
                    profiles = bus.keymapProfiles,
                    activeProfileId = bus.activeKeymapProfileId,
                    config = imported
                )
                LvngRuntimeBus.update {
                    it.copy(
                        keyboardMouseConfig = imported,
                        keymapProfiles = updatedProfiles,
                        activeKeymapProfileId = activeId
                    )
                }
                withContext(Dispatchers.IO) {
                    LvngPreferencesRepository(applicationContext).saveKeymapProfilesState(
                        profiles = updatedProfiles,
                        activeProfileId = activeId,
                        activeConfig = imported
                    )
                }
                val dm = resources.displayMetrics
                LvngShizukuManager.setKeymapConfigAsync(
                    config = imported,
                    screenWidth = dm.widthPixels,
                    screenHeight = dm.heightPixels,
                    rotation = 0,
                    captureOnly = isEditMode
                )
                Toast.makeText(
                    this@KeymapTransferActivity,
                    "Keymap masuk (${imported.nodes.size} tombol)",
                    Toast.LENGTH_LONG
                ).show()
            }.onFailure { err ->
                Toast.makeText(
                    this@KeymapTransferActivity,
                    err.message ?: "File keymap salah",
                    Toast.LENGTH_LONG
                ).show()
            }
            finish()
        }
    }

    private val createDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri == null) {
            finish()
            return@registerForActivityResult
        }
        val cfg = LvngRuntimeBus.state.value.keyboardMouseConfig
        lifecycleScope.launch {
            val writeRes = withContext(Dispatchers.IO) {
                KeymapTemplateStorage.writeTemplateToUri(applicationContext, uri, cfg)
            }
            writeRes.onSuccess {
                Toast.makeText(
                    this@KeymapTransferActivity,
                    "Keymap kesimpen (.json)",
                    Toast.LENGTH_LONG
                ).show()
            }.onFailure { err ->
                Toast.makeText(
                    this@KeymapTransferActivity,
                    err.message ?: "Gagal simpen file",
                    Toast.LENGTH_LONG
                ).show()
            }
            finish()
        }
    }

    private val shareSheetLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LvngRuntimeBus.update { it.copy(isTransferringKeymapFile = true) }

        if (savedInstanceState != null) {
            dispatched = true
            return
        }

        val mode = intent?.getStringExtra(EXTRA_MODE) ?: MODE_IMPORT
        if (!dispatched) {
            dispatched = true
            when (mode) {
                MODE_IMPORT -> {
                    openDocumentLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                }
                MODE_SAVE_AS -> {
                    val suggestedName = intent?.getStringExtra(EXTRA_FILE_NAME)
                        ?: KeymapTemplateStorage.buildDefaultFileName()
                    createDocumentLauncher.launch(suggestedName)
                }
                MODE_SHARE -> {
                    val shareUriStr = intent?.getStringExtra(EXTRA_SHARE_URI)
                    val fileName = intent?.getStringExtra(EXTRA_FILE_NAME) ?: "lvng_keymap.json"
                    val shareUri = shareUriStr?.let { runCatching { Uri.parse(it) }.getOrNull() }
                    if (shareUri != null) {
                        val chooser = KeymapTemplateStorage.buildShareChooserIntent(
                            this,
                            shareUri,
                            fileName
                        )
                        runCatching { shareSheetLauncher.launch(chooser) }
                            .onFailure { finish() }
                    } else {
                        finish()
                    }
                }
                else -> finish()
            }
        }
    }

    override fun onDestroy() {
        LvngRuntimeBus.update { it.copy(isTransferringKeymapFile = false) }
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_MODE = "lvng_transfer_mode"
        private const val EXTRA_FILE_NAME = "lvng_transfer_file_name"
        private const val EXTRA_SHARE_URI = "lvng_transfer_share_uri"

        private const val MODE_IMPORT = "import"
        private const val MODE_SAVE_AS = "save_as"
        private const val MODE_SHARE = "share"

        fun launchImport(context: Context) {
            val intent = Intent(context, KeymapTransferActivity::class.java).apply {
                putExtra(EXTRA_MODE, MODE_IMPORT)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }

        fun launchSaveAs(context: Context, fileName: String = KeymapTemplateStorage.buildDefaultFileName()) {
            val intent = Intent(context, KeymapTransferActivity::class.java).apply {
                putExtra(EXTRA_MODE, MODE_SAVE_AS)
                putExtra(EXTRA_FILE_NAME, fileName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }

        fun launchShare(context: Context, shareUri: Uri, fileName: String) {
            val intent = Intent(context, KeymapTransferActivity::class.java).apply {
                putExtra(EXTRA_MODE, MODE_SHARE)
                putExtra(EXTRA_SHARE_URI, shareUri.toString())
                putExtra(EXTRA_FILE_NAME, fileName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
