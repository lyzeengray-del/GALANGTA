package com.example.data

import android.content.Context
import android.media.MediaDrm
import android.os.Build
import android.provider.Settings
import java.security.MessageDigest
import java.util.UUID

data class DeviceIdentity(
    val primaryDeviceId: String,
    val legacyCachedDeviceId: String? = null,
    val legacyAndroidIdPrefix: String? = null
)

object DeviceIdentityMatcher {
    private val LEGACY_RANDOM_FORMAT_REGEX = Regex("^[a-zA-Z0-9_-]{8,12}-[0-9a-f]{16}$")
    private val WIDEVINE_UUID = UUID(-0x121074568629b532L, -0x5c37d8232ae2de13L)

    fun readAndroidId(context: Context): String? = runCatching {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
    }.getOrNull()

    fun readWidevineIdHex(): String? {
        var drm: MediaDrm? = null
        return try {
            drm = MediaDrm(WIDEVINE_UUID)
            val bytes = drm.getPropertyByteArray(MediaDrm.PROPERTY_DEVICE_UNIQUE_ID)
            if (bytes.isEmpty()) null else sha256BytesHex(bytes)
        } catch (_: Throwable) {
            null
        } finally {
            try {
                if (drm != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        drm.close()
                    } else {
                        @Suppress("DEPRECATION")
                        drm.release()
                    }
                }
            } catch (_: Throwable) {
            }
        }
    }

    fun computeDeterministicDeviceId(
        androidIdRaw: String?,
        widevineIdHex: String?,
        brand: String = Build.BRAND.orEmpty(),
        manufacturer: String = Build.MANUFACTURER.orEmpty(),
        model: String = Build.MODEL.orEmpty(),
        device: String = Build.DEVICE.orEmpty(),
        board: String = Build.BOARD.orEmpty(),
        hardware: String = Build.HARDWARE.orEmpty(),
        fallbackPersistentId: String? = null
    ): String {
        val cleanAndroidId = sanitizeAndroidId(androidIdRaw)
        val cleanWidevine = widevineIdHex?.trim()?.lowercase()?.takeIf { it.length >= 16 }
        val hwParts = listOf(
            brand.trim(),
            manufacturer.trim(),
            model.trim(),
            device.trim(),
            board.trim(),
            hardware.trim()
        ).joinToString("|")

        return when {
            cleanAndroidId != null -> {
                val digest = sha256Hex("lvng_hw_v2|aid:$cleanAndroidId|$hwParts")
                "lvng2_${digest.take(40)}"
            }
            cleanWidevine != null -> {
                val digest = sha256Hex("lvng_hw_v2|wv:$cleanWidevine|$hwParts")
                "lvng2_${digest.take(40)}"
            }
            !fallbackPersistentId.isNullOrBlank() && fallbackPersistentId.length >= 6 -> {
                fallbackPersistentId
            }
            else -> ""
        }
    }

    fun sanitizeAndroidId(raw: String?): String? {
        val cleaned = raw.orEmpty().replace(Regex("[^a-zA-Z0-9_-]"), "").lowercase()
        if (cleaned.length < 8) return null
        if (cleaned == "9774d56d682e549c" || cleaned.all { it == '0' }) return null
        return cleaned
    }

    fun androidIdLegacyPrefix(raw: String?): String? {
        val cleanedRaw = raw.orEmpty().replace(Regex("[^a-zA-Z0-9_-]"), "")
        val lower = cleanedRaw.lowercase()
        if (lower.length < 8 || lower == "9774d56d682e549c" || lower.all { it == '0' }) {
            return null
        }
        return cleanedRaw.take(12)
    }

    fun isLegacyRandomFormat(id: String?): Boolean {
        if (id.isNullOrBlank()) return false
        return LEGACY_RANDOM_FORMAT_REGEX.matches(id.trim())
    }

    fun isSameDevice(accountBoundDeviceId: String, local: DeviceIdentity): Boolean {
        val bound = accountBoundDeviceId.trim()
        if (bound.isBlank()) return false

        // 1. Primary deterministic hardware match (immune to logout, clear data, reinstall, and backup spoofing)
        if (bound == local.primaryDeviceId) return true

        // 2. Legacy pre-update accounts (<androidId12>-<random16>) on the exact same physical device
        if (isLegacyRandomFormat(bound)) {
            val prefix = local.legacyAndroidIdPrefix
            val cached = local.legacyCachedDeviceId?.trim()
            if (!cached.isNullOrBlank() && isLegacyRandomFormat(cached) && bound == cached) {
                if (prefix == null || bound.startsWith("$prefix-", ignoreCase = true)) {
                    return true
                }
            }
            if (!prefix.isNullOrBlank() && prefix.length >= 8 &&
                bound.startsWith("$prefix-", ignoreCase = true)
            ) {
                return true
            }
        }

        return false
    }

    fun sha256Hex(raw: String): String =
        sha256BytesHex(raw.toByteArray(Charsets.UTF_8))

    private fun sha256BytesHex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}
