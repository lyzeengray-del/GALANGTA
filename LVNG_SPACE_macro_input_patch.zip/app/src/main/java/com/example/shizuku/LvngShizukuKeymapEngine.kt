package com.example.shizuku

import android.os.Build
import android.os.Process as AndroidProcess
import android.os.SystemClock
import android.system.Os
import android.util.Log
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.example.input.LvngInputDeviceMonitor
import com.example.model.KeyTriggerBehavior
import com.example.model.KeyboardMouseConfig
import com.example.model.KeyboardMouseJsonCodec
import com.example.model.KeyboardMouseNode
import com.example.model.KeymapActionType
import com.example.model.MouseTweaksConfig
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.hypot
import kotlin.math.sqrt

interface VirtualPointerHost {
    fun ensureInjectorStarted(): Boolean
    fun upsertVirtualPointer(pointerId: Int, xPx: Float, yPx: Float): Boolean
    fun moveVirtualPointer(pointerId: Int, xPx: Float, yPx: Float): Boolean
    fun removeVirtualPointer(pointerId: Int): Boolean
    fun tapVirtualPointer(pointerId: Int, xPx: Float, yPx: Float, holdMs: Long)
    fun releaseAllKeymapPointers()
}

/**
 * Shizuku (`uid = 2000`) physical Keyboard & Mouse Keymap Engine for Android 11–16.
 * Supports 3 capture tiers so ALL USB OTG & Bluetooth keyboards/mice work:
 * 1) Direct `/dev/input/event*` Linux `input_event` reader (`dumpsys input` + `getevent -lp` + sysfs discovery).
 * 2) `InputMonitor` `SOURCE_MOUSE` / `SOURCE_MOUSE_RELATIVE` fallback when kernel evdev mouse is SELinux-blocked.
 * 3) Host / `LvngKeyboardBridgeService` (`AccessibilityService`) key forwarding when kernel evdev keyboard is SELinux-blocked.
 *
 * Drives `WASD_JOYSTICK` (slot 16), `MOUSE_AIM` / `FPS Look` (slot 17), `AIM_PAN` LMB Fire + `KEY_TAP` (`Sentuh`) (slots 18..28).
 */
class LvngShizukuKeymapEngine(
    private val host: VirtualPointerHost,
    private val runDirectInTests: Boolean = false
) {
    private val stateLock = Any()
    private val active = AtomicBoolean(false)
    private val injectionActive = AtomicBoolean(false)
    private val scannerRunning = AtomicBoolean(false)

    @Volatile
    var screenWidth: Int = 1080
        private set

    @Volatile
    var screenHeight: Int = 2400
        private set

    @Volatile
    var displayRotation: Int = 0
        private set

    @Volatile
    var config: KeyboardMouseConfig = KeyboardMouseConfig()
        private set

    @Volatile
    var isAimLocked: Boolean = false
        private set

    @Volatile
    var isOsPointerCaptureActive: Boolean = false
        private set

    @Volatile
    private var lastCapturedMouseAtMs: Long = 0L

    private var lastToggleAtMs: Long = 0L

    @Volatile
    var inputSummary: String = "Keymap nonaktif"
        private set

    private val lastCapturedKeyCode = AtomicInteger(0)
    private val lastCapturedKeySeq = AtomicLong(0L)

    // Key & Toggle runtime state (protected by stateLock)
    private val pressedCanonicalKeys = HashSet<Int>()
    private val pressedAimPanKeys = HashSet<Int>()
    private val keyNodeToSlot = HashMap<String, Int>()
    private val activeToggledNodes = HashSet<String>()
    private val wasdPressedSet = HashSet<Int>()
    private var isWasdDown = false
    private var wasdTargetX = 0f
    private var wasdTargetY = 0f
    private var isWasdRampActive = false

    // Mouse Aim & AimPan Drag state + zero-loss residual smoothing (protected by stateLock)
    private var isAimDown = false
    private var aimCurX = 0f
    private var aimCurY = 0f
    private var isAimPanDown = false
    private var aimPanCurX = 0f
    private var aimPanCurY = 0f
    private var smoothRemainX = 0f
    private var smoothRemainY = 0f
    private var pendingAimDx = 0f
    private var pendingAimDy = 0f
    private var aimFlushScheduled = false
    private val aimGeneration = AtomicLong(0L)

    // Dedup map for evdev vs Accessibility/host bridge ((canonicalCode shl 1) or isDownBit -> elapsedRealtime)
    private val lastEvdevKeyTimeMap = ConcurrentHashMap<Int, Long>()

    // InputMonitor mouse fallback state (protected by stateLock)
    private var fwLastMouseDevId = -1
    private var fwLastMouseX = Float.NaN
    private var fwLastMouseY = Float.NaN
    private var fwMouseButtonsMask = 0

    @Volatile
    private var lastFwDeviceSignature: String = ""

    private val touchDispatchExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "LvngKeymapTouch").apply {
            priority = Thread.MAX_PRIORITY
            isDaemon = true
        }
    }

    private val aimScheduler = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "LvngAimDrain").apply {
            priority = Thread.MAX_PRIORITY
            isDaemon = true
        }
    }

    private val tapExecutor = Executors.newCachedThreadPool { r ->
        Thread(r, "LvngKeyTap").apply { isDaemon = true }
    }

    private inline fun dispatchTouch(crossinline block: () -> Unit) {
        if (runDirectInTests) {
            block()
        } else {
            touchDispatchExecutor.execute { block() }
        }
    }

    private fun safeSleepMs(ms: Long) {
        if (!runDirectInTests && ms > 0L) {
            SystemClock.sleep(ms)
        }
    }

    private fun safeElapsedMs(): Long {
        return if (runDirectInTests) {
            System.nanoTime() / 1_000_000L
        } else {
            SystemClock.elapsedRealtime()
        }
    }

    private data class ReaderHandle(
        val eventName: String,
        val deviceDesc: String,
        val isMouse: Boolean,
        val isKeyboard: Boolean,
        val stopFlag: AtomicBoolean,
        val thread: Thread,
        @Volatile var stream: FileInputStream? = null
    )

    private val activeReaders = ConcurrentHashMap<String, ReaderHandle>()
    private var hotplugThread: Thread? = null

    private val structEventBytes: Int = runCatching {
        val arch = Os.uname().machine.lowercase()
        if (arch.contains("64") || arch.contains("aarch64") || arch.contains("x86_64")) 24 else 16
    }.getOrElse {
        runCatching { if (AndroidProcess.is64Bit()) 24 else 16 }.getOrDefault(24)
    }

    fun isActiveEngine(): Boolean = injectionActive.get()

    fun hasEvdevKeyboard(): Boolean = activeReaders.values.any { it.isKeyboard && it.thread.isAlive }

    fun hasEvdevMouse(): Boolean = activeReaders.values.any { it.isMouse && it.thread.isAlive }

    fun needsAccessibilityBridge(): Boolean {
        val fw = readFrameworkInputDevices()
        return fw.keyboards.isNotEmpty() && !hasEvdevKeyboard()
    }

    fun updateConfig(
        jsonStr: String,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        captureOnly: Boolean = false
    ): Boolean {
        val parsed = KeyboardMouseJsonCodec.decode(jsonStr)
        return updateParsedConfig(parsed, screenW, screenH, rotation, captureOnly, skipReaders = false)
    }

    fun updateParsedConfig(
        parsedInput: KeyboardMouseConfig,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        captureOnly: Boolean = false,
        skipReaders: Boolean = false
    ): Boolean {
        // Unconditionally enforce locked internal constant 16450
        val parsed = parsedInput.copy(
            tweaks = parsedInput.tweaks.copy(
                aimPanInternalTweak = AIM_PAN_INTERNAL_TWEAK
            )
        )
        synchronized(stateLock) {
            config = parsed
            if (screenW > 0) screenWidth = screenW
            if (screenH > 0) screenHeight = screenH
            displayRotation = rotation
        }

        val wantInjection = parsed.isActive && parsed.nodes.isNotEmpty()
        if (!wantInjection && !captureOnly) {
            stop()
            return false
        }

        if (wantInjection) {
            if (!host.ensureInjectorStarted()) {
                injectionActive.set(false)
                inputSummary = "TouchInjector gagal dimulai"
                if (!captureOnly) return false
            } else {
                val wasInj = injectionActive.getAndSet(true)
                synchronized(stateLock) {
                    val hasAimNode = parsed.nodes.any {
                        it.type == KeymapActionType.MOUSE_AIM || it.type == KeymapActionType.AIM_PAN
                    }
                    if (hasAimNode && parsed.tweaks.autoLockAimOnEnable && !wasInj) {
                        isAimLocked = true
                    } else if (!hasAimNode) {
                        isAimLocked = false
                    }
                }
            }
        } else {
            val wasInj = injectionActive.getAndSet(false)
            if (wasInj) {
                releaseInjectionState()
            }
        }

        if (!skipReaders) {
            startReadersIfNeeded()
        } else {
            active.set(wantInjection)
        }
        return injectionActive.get()
    }

    fun getLastCapturedKey(): Pair<Int, Long> =
        lastCapturedKeyCode.get() to lastCapturedKeySeq.get()

    fun onHostKeyEvent(androidKeyCode: Int, isDown: Boolean) {
        if (androidKeyCode == KeyEvent.KEYCODE_UNKNOWN || androidKeyCode == 0) return
        if (isDown) {
            lastCapturedKeyCode.set(androidKeyCode)
            lastCapturedKeySeq.incrementAndGet()
        }
        val evdevDedupKey = (androidKeyCode shl 1) or (if (isDown) 1 else 0)
        val lastEvdevAt = lastEvdevKeyTimeMap[evdevDedupKey] ?: 0L
        if (safeElapsedMs() - lastEvdevAt < 90L) {
            // Already delivered synchronously by kernel evdev reader
            return
        }
        if (injectionActive.get()) {
            handleCanonicalKeyEvent(androidKeyCode, isDown, fromEvdev = false)
        }
    }

    fun onHostCapturedMouseEvent(
        dx: Float,
        dy: Float,
        vScroll: Float,
        actionMasked: Int,
        actionButton: Int,
        buttonState: Int,
        isPointerCaptureActive: Boolean
    ) {
        isOsPointerCaptureActive = isPointerCaptureActive
        if (isPointerCaptureActive) {
            lastCapturedMouseAtMs = safeElapsedMs()
        }
        if (!active.get()) return
        if (hasEvdevMouse()) return

        processFrameworkMouseAction(
            actionMasked = actionMasked,
            actionButton = actionButton,
            buttonState = buttonState,
            vScroll = vScroll,
            relDx = dx,
            relDy = dy,
            deviceId = -1,
            absX = Float.NaN,
            absY = Float.NaN,
            fromPointerCapture = isPointerCaptureActive
        )
    }

    fun onFrameworkMouseEvent(me: MotionEvent) {
        if (!active.get()) return
        val isMouseSrc =
            (me.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (me.source and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
        if (!isMouseSrc) return
        // Skip InputMonitor fallback if evdev mouse is active OR PointerCapture is actively delivering events
        if (hasEvdevMouse()) return
        if (isOsPointerCaptureActive && (safeElapsedMs() - lastCapturedMouseAtMs) < 150L) return

        val isMoveLike = me.actionMasked == MotionEvent.ACTION_MOVE ||
            me.actionMasked == MotionEvent.ACTION_HOVER_MOVE ||
            me.actionMasked == MotionEvent.ACTION_DOWN ||
            me.actionMasked == MotionEvent.ACTION_BUTTON_PRESS
        var relX = 0f
        var relY = 0f
        if (isMoveLike) {
            val isRelSrc =
                (me.source and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
            val histSize = me.historySize
            for (h in 0 until histSize) {
                val hRx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    me.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_X, h)
                } else 0f
                val hRy = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    me.getHistoricalAxisValue(MotionEvent.AXIS_RELATIVE_Y, h)
                } else 0f
                if (hRx != 0f || hRy != 0f) {
                    relX += hRx
                    relY += hRy
                } else if (isRelSrc) {
                    relX += me.getHistoricalX(h)
                    relY += me.getHistoricalY(h)
                }
            }
            val curRx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                me.getAxisValue(MotionEvent.AXIS_RELATIVE_X)
            } else 0f
            val curRy = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                me.getAxisValue(MotionEvent.AXIS_RELATIVE_Y)
            } else 0f
            if (curRx != 0f || curRy != 0f) {
                relX += curRx
                relY += curRy
            } else if (isRelSrc) {
                relX += me.x
                relY += me.y
            }
        }

        processFrameworkMouseAction(
            actionMasked = me.actionMasked,
            actionButton = me.actionButton,
            buttonState = me.buttonState,
            vScroll = me.getAxisValue(MotionEvent.AXIS_VSCROLL),
            relDx = relX,
            relDy = relY,
            deviceId = me.deviceId,
            absX = me.x,
            absY = me.y,
            fromPointerCapture = false
        )
    }

    private fun processFrameworkMouseAction(
        actionMasked: Int,
        actionButton: Int,
        buttonState: Int,
        vScroll: Float,
        relDx: Float,
        relDy: Float,
        deviceId: Int,
        absX: Float,
        absY: Float,
        fromPointerCapture: Boolean
    ) {
        when (actionMasked) {
            MotionEvent.ACTION_SCROLL -> {
                if (vScroll > 0f) {
                    lastCapturedKeyCode.set(LvngKeyCodes.MOUSE_SCROLL_UP)
                    lastCapturedKeySeq.incrementAndGet()
                    firePulseKey(LvngKeyCodes.MOUSE_SCROLL_UP)
                } else if (vScroll < 0f) {
                    lastCapturedKeyCode.set(LvngKeyCodes.MOUSE_SCROLL_DOWN)
                    lastCapturedKeySeq.incrementAndGet()
                    firePulseKey(LvngKeyCodes.MOUSE_SCROLL_DOWN)
                }
            }

            MotionEvent.ACTION_BUTTON_PRESS -> {
                val btnBit = actionButtonToBitMask(actionButton)
                val shouldDispatch = synchronized(stateLock) {
                    if (!fromPointerCapture && !absX.isNaN() && !absY.isNaN()) {
                        fwLastMouseDevId = deviceId
                        fwLastMouseX = absX
                        fwLastMouseY = absY
                    }
                    if (btnBit != 0 && (fwMouseButtonsMask and btnBit) == 0) {
                        fwMouseButtonsMask = fwMouseButtonsMask or btnBit
                        true
                    } else {
                        btnBit == 0
                    }
                }
                if (shouldDispatch) {
                    val code = androidButtonToCanonical(actionButton, buttonState, isPress = true)
                    if (code != 0) handleCanonicalKeyEvent(code, isDown = true)
                }
                if (relDx != 0f || relDy != 0f) {
                    handleMouseDelta(relDx, relDy)
                }
            }

            MotionEvent.ACTION_BUTTON_RELEASE -> {
                val btnBit = actionButtonToBitMask(actionButton)
                val shouldDispatch = synchronized(stateLock) {
                    if (!fromPointerCapture && !absX.isNaN() && !absY.isNaN()) {
                        fwLastMouseDevId = deviceId
                        fwLastMouseX = absX
                        fwLastMouseY = absY
                    }
                    if (btnBit != 0 && (fwMouseButtonsMask and btnBit) != 0) {
                        fwMouseButtonsMask = fwMouseButtonsMask and btnBit.inv()
                        true
                    } else {
                        btnBit == 0
                    }
                }
                if (shouldDispatch) {
                    val code = androidButtonToCanonical(actionButton, buttonState, isPress = false)
                    if (code != 0) handleCanonicalKeyEvent(code, isDown = false)
                }
            }

            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val prevMask: Int
                synchronized(stateLock) {
                    prevMask = fwMouseButtonsMask
                    fwMouseButtonsMask = buttonState
                    if (!fromPointerCapture && !absX.isNaN() && !absY.isNaN()) {
                        fwLastMouseDevId = deviceId
                        fwLastMouseX = absX
                        fwLastMouseY = absY
                    }
                }
                val changed = prevMask xor buttonState
                syncButtonMaskBit(changed, buttonState, MotionEvent.BUTTON_PRIMARY, LvngKeyCodes.MOUSE_LEFT)
                syncButtonMaskBit(changed, buttonState, MotionEvent.BUTTON_SECONDARY, LvngKeyCodes.MOUSE_RIGHT)
                syncButtonMaskBit(changed, buttonState, MotionEvent.BUTTON_TERTIARY, LvngKeyCodes.MOUSE_MIDDLE)
                syncButtonMaskBit(changed, buttonState, MotionEvent.BUTTON_BACK, LvngKeyCodes.MOUSE_SIDE_BACK)
                syncButtonMaskBit(changed, buttonState, MotionEvent.BUTTON_FORWARD, LvngKeyCodes.MOUSE_SIDE_FORWARD)
                if (actionMasked == MotionEvent.ACTION_DOWN && (relDx != 0f || relDy != 0f)) {
                    handleMouseDelta(relDx, relDy)
                }
            }

            MotionEvent.ACTION_HOVER_MOVE, MotionEvent.ACTION_MOVE -> {
                // Reconcile hardware mouse buttons tracked via framework events so missed
                // ACTION_BUTTON_PRESS / ACTION_DOWN during focus changes still engage LMB AimPan.
                val pressedChanges = ArrayList<Int>(2)
                val releasedChanges = ArrayList<Int>(2)
                synchronized(stateLock) {
                    val bits = intArrayOf(
                        MotionEvent.BUTTON_PRIMARY,
                        MotionEvent.BUTTON_SECONDARY,
                        MotionEvent.BUTTON_TERTIARY,
                        MotionEvent.BUTTON_BACK,
                        MotionEvent.BUTTON_FORWARD
                    )
                    for (bit in bits) {
                        val isDownInEvent = (buttonState and bit) != 0
                        val wasDownInMask = (fwMouseButtonsMask and bit) != 0
                        if (isDownInEvent && !wasDownInMask) {
                            fwMouseButtonsMask = fwMouseButtonsMask or bit
                            val c = androidButtonToCanonical(bit, buttonState, isPress = true)
                            if (c != 0) pressedChanges.add(c)
                        } else if (!isDownInEvent && wasDownInMask) {
                            fwMouseButtonsMask = fwMouseButtonsMask and bit.inv()
                            val c = androidButtonToCanonical(bit, buttonState, isPress = false)
                            if (c != 0) releasedChanges.add(c)
                        }
                    }
                }
                for (c in pressedChanges) handleCanonicalKeyEvent(c, isDown = true)
                for (c in releasedChanges) handleCanonicalKeyEvent(c, isDown = false)

                var dx = relDx
                var dy = relDy

                if (!fromPointerCapture) {
                    synchronized(stateLock) {
                        if (dx == 0f && dy == 0f && !absX.isNaN() && !absY.isNaN()) {
                            if (fwLastMouseDevId == deviceId && !fwLastMouseX.isNaN() && !fwLastMouseY.isNaN()) {
                                val candDx = absX - fwLastMouseX
                                val candDy = absY - fwLastMouseY
                                if (hypot(candDx, candDy) < 400f) {
                                    dx = candDx
                                    dy = candDy
                                }
                            }
                        }
                        fwLastMouseDevId = deviceId
                        fwLastMouseX = absX
                        fwLastMouseY = absY
                    }
                }

                if (dx != 0f || dy != 0f) {
                    handleMouseDelta(dx, dy)
                }
            }
        }
    }

    private fun actionButtonToBitMask(actionBtn: Int): Int {
        return when (actionBtn) {
            MotionEvent.BUTTON_PRIMARY,
            MotionEvent.BUTTON_SECONDARY,
            MotionEvent.BUTTON_TERTIARY,
            MotionEvent.BUTTON_BACK,
            MotionEvent.BUTTON_FORWARD -> actionBtn
            else -> 0
        }
    }

    private fun syncButtonMaskBit(changed: Int, newState: Int, btnBit: Int, canonical: Int) {
        if ((changed and btnBit) != 0) {
            handleCanonicalKeyEvent(canonical, isDown = (newState and btnBit) != 0)
        }
    }

    private fun androidButtonToCanonical(actionBtn: Int, btnState: Int, isPress: Boolean): Int {
        return when (actionBtn) {
            MotionEvent.BUTTON_PRIMARY -> LvngKeyCodes.MOUSE_LEFT
            MotionEvent.BUTTON_SECONDARY -> LvngKeyCodes.MOUSE_RIGHT
            MotionEvent.BUTTON_TERTIARY -> LvngKeyCodes.MOUSE_MIDDLE
            MotionEvent.BUTTON_BACK -> LvngKeyCodes.MOUSE_SIDE_BACK
            MotionEvent.BUTTON_FORWARD -> LvngKeyCodes.MOUSE_SIDE_FORWARD
            else -> when {
                isPress && (btnState and MotionEvent.BUTTON_PRIMARY) != 0 -> LvngKeyCodes.MOUSE_LEFT
                isPress && (btnState and MotionEvent.BUTTON_SECONDARY) != 0 -> LvngKeyCodes.MOUSE_RIGHT
                else -> 0
            }
        }
    }

    private fun releaseInjectionState() {
        aimGeneration.incrementAndGet()
        synchronized(stateLock) {
            pressedCanonicalKeys.clear()
            pressedAimPanKeys.clear()
            keyNodeToSlot.clear()
            activeToggledNodes.clear()
            wasdPressedSet.clear()
            isWasdDown = false
            isWasdRampActive = false
            isAimDown = false
            isAimPanDown = false
            isAimLocked = false
            isOsPointerCaptureActive = false
            smoothRemainX = 0f
            smoothRemainY = 0f
            pendingAimDx = 0f
            pendingAimDy = 0f
            aimFlushScheduled = false
            fwLastMouseDevId = -1
            fwLastMouseX = Float.NaN
            fwLastMouseY = Float.NaN
            fwMouseButtonsMask = 0
        }
        dispatchTouch {
            runCatching { host.releaseAllKeymapPointers() }
        }
    }

    fun stop() {
        val wasInj = injectionActive.getAndSet(false)
        active.set(false)
        scannerRunning.set(false)
        aimGeneration.incrementAndGet()
        lastFwDeviceSignature = ""
        hotplugThread?.interrupt()
        hotplugThread = null
        closeAllReaders()
        if (wasInj) {
            releaseInjectionState()
        } else {
            synchronized(stateLock) {
                pressedCanonicalKeys.clear()
                pressedAimPanKeys.clear()
                keyNodeToSlot.clear()
                activeToggledNodes.clear()
                wasdPressedSet.clear()
                isWasdDown = false
                isWasdRampActive = false
                isAimDown = false
                isAimPanDown = false
                isAimLocked = false
                isOsPointerCaptureActive = false
                smoothRemainX = 0f
                smoothRemainY = 0f
                pendingAimDx = 0f
                pendingAimDy = 0f
                aimFlushScheduled = false
                fwLastMouseDevId = -1
                fwLastMouseX = Float.NaN
                fwLastMouseY = Float.NaN
                fwMouseButtonsMask = 0
            }
        }
        inputSummary = "Keymap nonaktif"
    }

    private fun startReadersIfNeeded() {
        val already = active.getAndSet(true)
        scanAndAttachDevices()
        if (!already || hotplugThread?.isAlive != true) {
            scannerRunning.set(true)
            hotplugThread = Thread({
                while (active.get() && scannerRunning.get() && !Thread.currentThread().isInterrupted) {
                    try {
                        Thread.sleep(1_600L)
                        if (active.get()) {
                            scanAndAttachDevices()
                        }
                    } catch (_: InterruptedException) {
                        break
                    } catch (_: Throwable) {
                    }
                }
            }, "LvngInputScanner").apply {
                isDaemon = true
                start()
            }
        }
    }

    private data class FrameworkDevSummary(
        val keyboards: List<String>,
        val mice: List<String>,
        val signature: String
    )

    private fun readFrameworkInputDevices(): FrameworkDevSummary {
        val kbs = LinkedHashSet<String>()
        val mice = LinkedHashSet<String>()
        val sigParts = ArrayList<String>()
        runCatching {
            val ids = InputDevice.getDeviceIds()
            for (id in ids) {
                val dev = InputDevice.getDevice(id) ?: continue
                val (isMouse, isKb) = LvngInputDeviceMonitor.classifyDevice(dev)
                val cleanName = dev.name?.trim().orEmpty().ifBlank { "HID-$id" }
                if (isMouse || isKb) {
                    sigParts.add("$id:$cleanName:${if (isMouse) 1 else 0}${if (isKb) 1 else 0}")
                }
                if (isMouse) mice.add(cleanName)
                if (isKb) kbs.add(cleanName)
            }
        }
        return FrameworkDevSummary(
            keyboards = kbs.toList(),
            mice = mice.toList(),
            signature = sigParts.sorted().joinToString("|")
        )
    }

    private fun scanAndAttachDevices() {
        val fwSummary = readFrameworkInputDevices()

        // Only prune dead readers whose node disappeared or thread died — never kill live healthy readers mid-gameplay!
        val deadNames = activeReaders.entries.filter { (name, handle) ->
            !handle.thread.isAlive || !File("/dev/input/$name").exists()
        }.map { it.key }
        deadNames.forEach { name ->
            activeReaders.remove(name)?.let { handle ->
                handle.stopFlag.set(true)
                runCatching { handle.stream?.close() }
                handle.thread.interrupt()
            }
        }

        val hasExternalFw = fwSummary.keyboards.isNotEmpty() || fwSummary.mice.isNotEmpty()
        val sigChanged = fwSummary.signature != lastFwDeviceSignature
        val missingAnyNeededReader = hasExternalFw &&
            ((fwSummary.keyboards.isNotEmpty() && !hasEvdevKeyboard()) ||
                (fwSummary.mice.isNotEmpty() && !hasEvdevMouse()))

        var openError: String? = null
        if (sigChanged || activeReaders.isEmpty() && (hasExternalFw || lastFwDeviceSignature.isEmpty()) || missingAnyNeededReader) {
            lastFwDeviceSignature = fwSummary.signature
            val discovered = discoverExternalInputNodes(fwSummary)
            discovered.forEach { dev ->
                if (!activeReaders.containsKey(dev.eventName)) {
                    val err = startReaderForNode(dev)
                    if (err != null) openError = err
                }
            }
        }

        val count = activeReaders.size
        val labels = activeReaders.values.joinToString(", ") {
            when {
                it.isMouse && it.isKeyboard -> "Combo(${it.deviceDesc})"
                it.isMouse -> "Mouse(${it.deviceDesc})"
                else -> "Keyboard(${it.deviceDesc})"
            }
        }

        val fwParts = mutableListOf<String>()
        if (fwSummary.keyboards.isNotEmpty()) {
            fwParts.add("Keyboard(${fwSummary.keyboards.joinToString("/") { it.take(14) }})")
        }
        if (fwSummary.mice.isNotEmpty()) {
            fwParts.add("Mouse(${fwSummary.mice.joinToString("/") { it.take(14) }})")
        }

        inputSummary = when {
            count > 0 && hasEvdevKeyboard() && (hasEvdevMouse() || fwSummary.mice.isEmpty()) ->
                "$count evdev aktif: $labels"
            count > 0 ->
                "Aktif ($labels) + Monitor Android"
            fwParts.isNotEmpty() -> {
                val errHint = if (openError != null) " • Mode LVNG Bridge" else ""
                "Terhubung: ${fwParts.joinToString(", ")}$errHint"
            }
            openError != null ->
                "Akses evdev ditolak ($openError)"
            else ->
                "Menunggu Keyboard / Mouse USB OTG atau Bluetooth..."
        }
    }

    private data class CandidateInputNode(
        val eventName: String,
        val path: String,
        val name: String,
        val isMouse: Boolean,
        val isKeyboard: Boolean
    )

    private data class ParsedShellNodeInfo(
        var name: String = "",
        var isMouse: Boolean = false,
        var isKeyboard: Boolean = false,
        var isExternal: Boolean = false,
        var isTouchscreen: Boolean = false
    )

    private fun isIgnoredDeviceName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.contains("lvng") ||
            lower.contains("uinput") ||
            lower.contains("gpio") ||
            lower.contains("qpnp") ||
            lower.contains("pmic") ||
            lower.contains("touchscreen") ||
            lower.contains("fts") ||
            lower.contains("goodix") ||
            lower.contains("synaptics") ||
            lower.contains("fingerprint") ||
            lower.contains("headset") ||
            lower.contains("haptics") ||
            lower.contains("hall") ||
            lower.contains("pwrkey")
    }

    private fun readShellQuickOutput(command: String): String {
        return runCatching {
            val proc = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val out = proc.inputStream.bufferedReader().readText()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                proc.waitFor(1_200L, TimeUnit.MILLISECONDS)
            } else {
                proc.waitFor()
            }
            if (proc.isAlive) proc.destroyForcibly()
            out
        }.getOrDefault("")
    }

    private fun inspectNodesViaDumpsysAndGetevent(): Map<String, ParsedShellNodeInfo> {
        val map = HashMap<String, ParsedShellNodeInfo>()

        // 1) Parse `dumpsys input` EventHub/InputReader devices (reliable even when sysfs is SELinux-blocked)
        val dumpsysOut = readShellQuickOutput("dumpsys input 2>/dev/null")
        if (dumpsysOut.isNotBlank()) {
            var curName = ""
            var curPath = ""
            var curExternal = false
            var curMouse = false
            var curKb = false
            var curTouch = false

            fun flushCurrent() {
                if (curPath.startsWith("/dev/input/event")) {
                    val evName = curPath.substringAfterLast('/')
                    val entry = map.getOrPut(evName) { ParsedShellNodeInfo() }
                    if (curName.isNotBlank() && entry.name.isBlank()) entry.name = curName
                    entry.isExternal = entry.isExternal || curExternal
                    entry.isMouse = entry.isMouse || curMouse
                    entry.isKeyboard = entry.isKeyboard || curKb
                    entry.isTouchscreen = entry.isTouchscreen || curTouch
                }
            }

            for (rawLine in dumpsysOut.lineSequence()) {
                val line = rawLine.trim()
                when {
                    line.startsWith("Device ") && line.contains(':') -> {
                        flushCurrent()
                        curName = line.substringAfter(':').trim()
                        curPath = ""
                        curExternal = false
                        curMouse = false
                        curKb = false
                        curTouch = false
                    }
                    line.startsWith("Name:", ignoreCase = true) -> {
                        curName = line.substringAfter(':').trim().trim('"')
                    }
                    line.startsWith("Path:", ignoreCase = true) -> {
                        curPath = line.substringAfter(':').trim()
                    }
                    line.startsWith("IsExternal:", ignoreCase = true) -> {
                        curExternal = line.contains("true", ignoreCase = true)
                    }
                    line.startsWith("Classes:", ignoreCase = true) -> {
                        val up = line.uppercase()
                        if (up.contains("TOUCH_MT") || up.contains("TOUCHSCREEN")) curTouch = true
                        if (up.contains("CURSOR") || up.contains("RELATIVE_MOUSE") || up.contains("MOUSE")) curMouse = true
                        if (up.contains("KEYBOARD") || up.contains("ALPHAKEY")) curKb = true
                    }
                    line.startsWith("Sources:", ignoreCase = true) -> {
                        val up = line.uppercase()
                        if (up.contains("TOUCHSCREEN")) curTouch = true
                        if (up.contains("MOUSE")) curMouse = true
                        if (up.contains("KEYBOARD")) curKb = true
                    }
                    line.startsWith("Input Dispatcher State:") -> {
                        flushCurrent()
                        break
                    }
                }
            }
            flushCurrent()
        }

        // 2) Parse `getevent -lp` for exact kernel REL/KEY/ABS capabilities
        val geteventOut = readShellQuickOutput("getevent -lp 2>/dev/null")
        if (geteventOut.isNotBlank()) {
            var curEvName = ""
            var curName = ""
            var hasRel = false
            var hasKey = false
            var hasAbsMt = false
            var hasKeyLetters = false
            var hasMouseBtn = false
            var inKeySection = false
            var inRelSection = false
            var inAbsSection = false

            fun flushGetevent() {
                if (curEvName.startsWith("event")) {
                    val entry = map.getOrPut(curEvName) { ParsedShellNodeInfo() }
                    if (curName.isNotBlank() && entry.name.isBlank()) entry.name = curName
                    if (hasAbsMt) entry.isTouchscreen = true
                    if (!hasAbsMt && (hasRel || hasMouseBtn)) entry.isMouse = true
                    if (!hasAbsMt && hasKey && hasKeyLetters) entry.isKeyboard = true
                }
            }

            for (rawLine in geteventOut.lineSequence()) {
                val line = rawLine.trim()
                when {
                    line.startsWith("add device ") && line.contains("/dev/input/event") -> {
                        flushGetevent()
                        curEvName = line.substringAfterLast('/').trim()
                        curName = ""
                        hasRel = false
                        hasKey = false
                        hasAbsMt = false
                        hasKeyLetters = false
                        hasMouseBtn = false
                        inKeySection = false
                        inRelSection = false
                        inAbsSection = false
                    }
                    line.startsWith("name:") -> {
                        curName = line.removePrefix("name:").trim().trim('"')
                    }
                    line.startsWith("KEY (") -> {
                        hasKey = true
                        inKeySection = true
                        inRelSection = false
                        inAbsSection = false
                    }
                    line.startsWith("REL (") -> {
                        hasRel = true
                        inKeySection = false
                        inRelSection = true
                        inAbsSection = false
                    }
                    line.startsWith("ABS (") -> {
                        inKeySection = false
                        inRelSection = false
                        inAbsSection = true
                    }
                    line.startsWith("MSC (") || line.startsWith("LED (") || line.startsWith("SW (") -> {
                        inKeySection = false
                        inRelSection = false
                        inAbsSection = false
                    }
                }
                val up = line.uppercase()
                if (inAbsSection && (up.contains("ABS_MT_POSITION") || up.contains("0035") || up.contains("0036"))) {
                    hasAbsMt = true
                }
                if (inKeySection) {
                    if (up.contains("BTN_LEFT") || up.contains("BTN_MOUSE") || up.contains("0110")) {
                        hasMouseBtn = true
                    }
                    if (up.contains("KEY_W") || up.contains("KEY_A") || up.contains("KEY_SPACE") ||
                        up.contains("KEY_ENTER") || up.contains("KEY_Q") || up.contains("KEY_F1")
                    ) {
                        hasKeyLetters = true
                    }
                }
                if (inRelSection && (up.contains("REL_X") || up.contains("0000"))) {
                    hasRel = true
                }
            }
            flushGetevent()
        }

        return map
    }

    private fun discoverExternalInputNodes(fwSummary: FrameworkDevSummary): List<CandidateInputNode> {
        val result = ArrayList<CandidateInputNode>()
        val frameworkNames = HashMap<String, Pair<Boolean, Boolean>>() // normalized name -> (isMouse, isKb)

        runCatching {
            val ids = InputDevice.getDeviceIds()
            for (id in ids) {
                val dev = InputDevice.getDevice(id) ?: continue
                val (isMouse, isKb) = LvngInputDeviceMonitor.classifyDevice(dev)
                if (isMouse || isKb) {
                    val key = dev.name.trim().lowercase()
                    val prev = frameworkNames[key]
                    frameworkNames[key] = ((prev?.first == true) || isMouse) to ((prev?.second == true) || isKb)
                }
            }
        }

        val shellMap = inspectNodesViaDumpsysAndGetevent()

        // Combine /dev/input directory listing + direct event0..31 probes + shellMap keys
        val candidateFiles = LinkedHashMap<String, File>()
        File("/dev/input").listFiles { _, n -> n.startsWith("event") }?.forEach { f ->
            candidateFiles[f.name] = f
        }
        shellMap.keys.forEach { evName ->
            if (!candidateFiles.containsKey(evName)) {
                val f = File("/dev/input/$evName")
                if (f.exists()) candidateFiles[evName] = f
            }
        }
        for (idx in 0..31) {
            val evName = "event$idx"
            if (!candidateFiles.containsKey(evName)) {
                val f = File("/dev/input/$evName")
                if (f.exists()) candidateFiles[evName] = f
            }
        }

        val hasAnyFwExternal = fwSummary.keyboards.isNotEmpty() || fwSummary.mice.isNotEmpty()

        for (file in candidateFiles.values.sortedBy { it.name.removePrefix("event").toIntOrNull() ?: 999 }) {
            val eventName = file.name
            val shellInfo = shellMap[eventName]
            val sysDev = File("/sys/class/input/$eventName/device")
            val sysName = runCatching { File(sysDev, "name").readText().trim() }.getOrDefault("")
            val devName = shellInfo?.name?.takeIf { it.isNotBlank() }
                ?: sysName.takeIf { it.isNotBlank() }
                ?: ""

            if (devName.isNotBlank() && isIgnoredDeviceName(devName)) {
                continue
            }
            if (shellInfo?.isTouchscreen == true) {
                continue
            }

            val lowerName = devName.lowercase()
            val fwExactOrFuzzy = if (lowerName.isNotBlank()) {
                frameworkNames[lowerName] ?: frameworkNames.entries.firstOrNull { (k, _) ->
                    k.contains(lowerName) || lowerName.contains(k)
                }?.value
            } else null

            var isMouse = (fwExactOrFuzzy?.first == true) || (shellInfo?.isMouse == true)
            var isKb = (fwExactOrFuzzy?.second == true) || (shellInfo?.isKeyboard == true && (shellInfo.isExternal || fwSummary.keyboards.isNotEmpty()))

            if (!isMouse && !isKb) {
                val relCaps = runCatching { File(sysDev, "capabilities/rel").readText().trim() }.getOrDefault("0")
                val absCaps = runCatching { File(sysDev, "capabilities/abs").readText().trim() }.getOrDefault("0")
                val keyCaps = runCatching { File(sysDev, "capabilities/key").readText().trim() }.getOrDefault("0")
                val relLast = relCaps.split(' ').lastOrNull()?.toLongOrNull(16) ?: 0L
                val hasRelXy = (relLast and 0x03L) == 0x03L
                val hasAbsMt = absCaps != "0" && absCaps.length > 4
                if (hasRelXy && !hasAbsMt) {
                    isMouse = true
                }
                val nonZeroKeyWords = keyCaps.split(' ').count { it != "0" && it.isNotBlank() }
                if (!hasAbsMt && nonZeroKeyWords >= 2) {
                    isKb = true
                }
            }

            // If shellInfo only marked IsExternal without classes and framework has external devices
            if (!isMouse && !isKb && shellInfo?.isExternal == true && hasAnyFwExternal) {
                isKb = fwSummary.keyboards.isNotEmpty()
                isMouse = fwSummary.mice.isNotEmpty()
            }

            if (isMouse || isKb) {
                result.add(
                    CandidateInputNode(
                        eventName = eventName,
                        path = file.absolutePath,
                        name = devName.ifBlank { eventName },
                        isMouse = isMouse,
                        isKeyboard = isKb
                    )
                )
            }
        }
        return result
    }

    private fun startReaderForNode(node: CandidateInputNode): String? {
        val stream = try {
            FileInputStream(node.path)
        } catch (t: Throwable) {
            Log.w(TAG, "Gagal membuka ${node.path} (${node.name}): ${t.message}")
            return "${node.eventName}:${t.javaClass.simpleName}"
        }

        val stopFlag = AtomicBoolean(false)
        val worker = Thread({
            runCatching {
                AndroidProcess.setThreadPriority(AndroidProcess.THREAD_PRIORITY_URGENT_DISPLAY)
            }
            val bufSize = structEventBytes * 32
            val raw = ByteArray(bufSize)
            val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            var accumDx = 0
            var accumDy = 0

            try {
                while (active.get() && !stopFlag.get() && !Thread.currentThread().isInterrupted) {
                    val readBytes = stream.read(raw)
                    if (readBytes < structEventBytes) {
                        if (readBytes < 0) break
                        continue
                    }

                    var off = 0
                    while (off + structEventBytes <= readBytes) {
                        val type: Int
                        val code: Int
                        val value: Int
                        if (structEventBytes == 24) {
                            type = bb.getShort(off + 16).toInt() and 0xFFFF
                            code = bb.getShort(off + 18).toInt() and 0xFFFF
                            value = bb.getInt(off + 20)
                        } else {
                            type = bb.getShort(off + 8).toInt() and 0xFFFF
                            code = bb.getShort(off + 10).toInt() and 0xFFFF
                            value = bb.getInt(off + 12)
                        }

                        when (type) {
                            EV_KEY -> {
                                if (value == 0 || value == 1) {
                                    val canonical = LvngKeyCodes.linuxEvKeyToCanonical(code)
                                    if (canonical != 0) {
                                        val evdevDedupKey = (canonical shl 1) or value
                                        lastEvdevKeyTimeMap[evdevDedupKey] = SystemClock.elapsedRealtime()
                                        handleCanonicalKeyEvent(canonical, isDown = (value == 1), fromEvdev = true)
                                    }
                                }
                            }
                            EV_REL -> {
                                when (code) {
                                    REL_X -> accumDx += value
                                    REL_Y -> accumDy += value
                                    REL_WHEEL -> {
                                        if (value > 0) {
                                            lastCapturedKeyCode.set(LvngKeyCodes.MOUSE_SCROLL_UP)
                                            lastCapturedKeySeq.incrementAndGet()
                                            firePulseKey(LvngKeyCodes.MOUSE_SCROLL_UP)
                                        } else if (value < 0) {
                                            lastCapturedKeyCode.set(LvngKeyCodes.MOUSE_SCROLL_DOWN)
                                            lastCapturedKeySeq.incrementAndGet()
                                            firePulseKey(LvngKeyCodes.MOUSE_SCROLL_DOWN)
                                        }
                                    }
                                }
                            }
                            EV_SYN -> {
                                if (code == SYN_REPORT && (accumDx != 0 || accumDy != 0)) {
                                    handleMouseDelta(accumDx.toFloat(), accumDy.toFloat())
                                    accumDx = 0
                                    accumDy = 0
                                }
                            }
                        }
                        off += structEventBytes
                    }
                }
            } catch (t: Throwable) {
                if (!stopFlag.get() && active.get()) {
                    Log.w(TAG, "Reader ${node.eventName} berhenti: ${t.message}")
                }
            } finally {
                runCatching { stream.close() }
                activeReaders.remove(node.eventName)
            }
        }, "LvngEv_${node.eventName}").apply {
            priority = Thread.MAX_PRIORITY
            isDaemon = true
        }

        val handle = ReaderHandle(
            eventName = node.eventName,
            deviceDesc = node.name.take(18),
            isMouse = node.isMouse,
            isKeyboard = node.isKeyboard,
            stopFlag = stopFlag,
            thread = worker,
            stream = stream
        )
        activeReaders[node.eventName] = handle
        worker.start()
        return null
    }

    private fun closeAllReaders() {
        val snapshot = activeReaders.values.toList()
        activeReaders.clear()
        snapshot.forEach { h ->
            h.stopFlag.set(true)
            runCatching { h.stream?.close() }
            h.thread.interrupt()
        }
    }

    private fun firePulseKey(canonicalCode: Int) {
        if (!injectionActive.get() || canonicalCode == KeyEvent.KEYCODE_UNKNOWN || canonicalCode == 0) return
        val cfg = config
        val w = screenWidth.toFloat().coerceAtLeast(1f)
        val h = screenHeight.toFloat().coerceAtLeast(1f)
        cfg.nodes.forEach { node ->
            if (node.type == KeymapActionType.KEY_TAP && node.keyCode == canonicalCode) {
                val slot = slotForNode(node.id)
                val tx = (node.xFraction * w).coerceIn(1f, w - 1f)
                val ty = (node.yFraction * h).coerceIn(1f, h - 1f)
                tapExecutor.execute {
                    host.tapVirtualPointer(slot, tx, ty, node.holdTapDurationMs.toLong())
                }
            }
        }
    }

    private fun handleCanonicalKeyEvent(
        canonicalCode: Int,
        isDown: Boolean,
        @Suppress("UNUSED_PARAMETER") fromEvdev: Boolean = false
    ) {
        if (canonicalCode == KeyEvent.KEYCODE_UNKNOWN || canonicalCode == 0) return
        if (isDown) {
            lastCapturedKeyCode.set(canonicalCode)
            lastCapturedKeySeq.incrementAndGet()
        }
        if (!injectionActive.get()) return

        val cfg = config
        val w = screenWidth.toFloat().coerceAtLeast(1f)
        val h = screenHeight.toFloat().coerceAtLeast(1f)

        // 1) Cursor Lock / Focus Toggle key (default F1, also matches HELP fallback if bound to F1)
        // Locks/unlocks MOUSE aim & cursor capture only; keyboard keys & joystick stay unaffected.
        val isToggleKey = canonicalCode == cfg.tweaks.cursorToggleKeyCode ||
            (cfg.tweaks.cursorToggleKeyCode == KeyEvent.KEYCODE_F1 && canonicalCode == KeyEvent.KEYCODE_HELP)
        if (isToggleKey) {
            if (isDown) {
                var shouldReleaseAim = false
                var shouldReleaseAimPan = false
                val nowMs = safeElapsedMs()
                synchronized(stateLock) {
                    if (!runDirectInTests && lastToggleAtMs > 0L && (nowMs - lastToggleAtMs) < 90L) {
                        return
                    }
                    lastToggleAtMs = nowMs
                    isAimLocked = !isAimLocked
                    if (!isAimLocked) {
                        aimGeneration.incrementAndGet()
                        pendingAimDx = 0f
                        pendingAimDy = 0f
                        smoothRemainX = 0f
                        smoothRemainY = 0f
                        aimFlushScheduled = false
                        isOsPointerCaptureActive = false
                        if (isAimDown) {
                            isAimDown = false
                            shouldReleaseAim = true
                        }
                        if (pressedAimPanKeys.isNotEmpty() || isAimPanDown) {
                            pressedAimPanKeys.clear()
                            isAimPanDown = false
                            shouldReleaseAimPan = true
                        }
                    }
                }
                if (shouldReleaseAim || shouldReleaseAimPan) {
                    dispatchTouch {
                        if (shouldReleaseAim) {
                            host.removeVirtualPointer(MOUSE_AIM_POINTER_ID)
                        }
                        if (shouldReleaseAimPan) {
                            host.removeVirtualPointer(AIM_PAN_POINTER_ID)
                        }
                    }
                }
            }
            return
        }

        // 2) AimPan Left Mouse Click Fire + Drag button (dedicated slot 18)
        // Requires cursor lock (F1) to be active; when cursor is unlocked, LMB acts as normal cursor click.
        if (canonicalCode == LvngKeyCodes.MOUSE_LEFT) {
            val aimPanNode = cfg.nodes.firstOrNull { it.type == KeymapActionType.AIM_PAN }
            if (aimPanNode != null) {
                val allowedToFire = isAimLocked
                if (isDown && allowedToFire) {
                    var startPanX = 0f
                    var startPanY = 0f
                    var releaseAimFirst = false
                    val freshPress = synchronized(stateLock) {
                        val added = pressedAimPanKeys.add(canonicalCode)
                        if (added) {
                            startPanX = (aimPanNode.xFraction * w).coerceIn(8f, w - 8f)
                            startPanY = (aimPanNode.yFraction * h).coerceIn(8f, h - 8f)
                            aimPanCurX = startPanX
                            aimPanCurY = startPanY
                            isAimPanDown = true
                            // Reset residual FPS Look delta so drag-shot starts cleanly from the Fire button
                            pendingAimDx = 0f
                            pendingAimDy = 0f
                            smoothRemainX = 0f
                            smoothRemainY = 0f
                            aimFlushScheduled = false
                            aimGeneration.incrementAndGet()
                            // Clean Mobilador handoff: keep right-side camera single-finger by lifting slot 17 AFTER slot 18 touches down
                            if (isAimDown) {
                                isAimDown = false
                                releaseAimFirst = true
                            }
                        }
                        added
                    }
                    if (freshPress) {
                        dispatchTouch {
                            host.upsertVirtualPointer(AIM_PAN_POINTER_ID, startPanX, startPanY)
                            if (releaseAimFirst) {
                                host.removeVirtualPointer(MOUSE_AIM_POINTER_ID)
                            }
                        }
                    }
                } else if (!isDown) {
                    val wasHeld = synchronized(stateLock) {
                        val removed = pressedAimPanKeys.remove(canonicalCode)
                        if (removed) {
                            isAimPanDown = false
                            pendingAimDx = 0f
                            pendingAimDy = 0f
                            smoothRemainX = 0f
                            smoothRemainY = 0f
                            aimFlushScheduled = false
                            aimGeneration.incrementAndGet()
                        }
                        removed
                    }
                    if (wasHeld) {
                        dispatchTouch {
                            host.removeVirtualPointer(AIM_PAN_POINTER_ID)
                        }
                    }
                }
                if (!isAimLocked) {
                    return
                }
            } else if (!isAimLocked && isDown) {
                // Cursor is unlocked via F1: allow normal OS mouse clicking instead of LMB key-tap injection
                return
            }
        }

        // 3) WASD Analog Joystick
        val wasdNode = cfg.nodes.firstOrNull { it.type == KeymapActionType.WASD_JOYSTICK }
        if (wasdNode != null && isWasdKey(wasdNode, canonicalCode)) {
            updateWasdVector(wasdNode, canonicalCode, isDown, w, h)
            return
        }

        // 4) Mapped Sentuh (KEY_TAP) nodes
        val matchingNodes = cfg.nodes.filter {
            it.type == KeymapActionType.KEY_TAP &&
                it.keyCode != KeyEvent.KEYCODE_UNKNOWN &&
                it.keyCode != 0 &&
                it.keyCode == canonicalCode
        }
        if (matchingNodes.isEmpty()) return

        for (node in matchingNodes) {
            val tx = (node.xFraction * w).coerceIn(1f, w - 1f)
            val ty = (node.yFraction * h).coerceIn(1f, h - 1f)
            val slot = slotForNode(node.id)

            when (node.triggerBehavior) {
                KeyTriggerBehavior.HOLD -> {
                    val transitionOk = synchronized(stateLock) {
                        if (isDown) pressedCanonicalKeys.add(canonicalCode)
                        else pressedCanonicalKeys.remove(canonicalCode)
                    }
                    if (transitionOk) {
                        dispatchTouch {
                            if (isDown) {
                                host.upsertVirtualPointer(slot, tx, ty)
                            } else {
                                host.removeVirtualPointer(slot)
                            }
                        }
                    }
                }
                KeyTriggerBehavior.TAP_ONCE -> {
                    if (isDown) {
                        if (runDirectInTests) {
                            host.tapVirtualPointer(slot, tx, ty, node.holdTapDurationMs.toLong())
                        } else {
                            tapExecutor.execute {
                                host.tapVirtualPointer(slot, tx, ty, node.holdTapDurationMs.toLong())
                            }
                        }
                    }
                }
                KeyTriggerBehavior.TOGGLE -> {
                    if (isDown) {
                        val nowLatched = synchronized(stateLock) {
                            if (activeToggledNodes.contains(node.id)) {
                                activeToggledNodes.remove(node.id)
                                false
                            } else {
                                activeToggledNodes.add(node.id)
                                true
                            }
                        }
                        dispatchTouch {
                            if (nowLatched) {
                                host.upsertVirtualPointer(slot, tx, ty)
                            } else {
                                host.removeVirtualPointer(slot)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun isWasdKey(node: KeyboardMouseNode, code: Int): Boolean {
        return code == node.wasdUpKeyCode ||
            code == node.wasdLeftKeyCode ||
            code == node.wasdDownKeyCode ||
            code == node.wasdRightKeyCode
    }

    private fun updateWasdVector(
        node: KeyboardMouseNode,
        code: Int,
        isDown: Boolean,
        w: Float,
        h: Float
    ) {
        val centerX = (node.xFraction * w).coerceIn(2f, w - 2f)
        val centerY = (node.yFraction * h).coerceIn(2f, h - 2f)
        val radiusPx = (node.radiusFraction * minOf(w, h)).coerceIn(32f, minOf(w, h) * 0.35f)

        var vx = 0f
        var vy = 0f
        var wasDownBefore: Boolean
        var shouldStartRamp = false
        var shouldMoveTarget = false
        var shouldRelease = false

        synchronized(stateLock) {
            wasDownBefore = isWasdDown
            if (isDown) wasdPressedSet.add(code) else wasdPressedSet.remove(code)

            if (wasdPressedSet.contains(node.wasdUpKeyCode)) vy -= 1f
            if (wasdPressedSet.contains(node.wasdDownKeyCode)) vy += 1f
            if (wasdPressedSet.contains(node.wasdLeftKeyCode)) vx -= 1f
            if (wasdPressedSet.contains(node.wasdRightKeyCode)) vx += 1f

            // Persistent Joystick Rule:
            // Only release WASD_POINTER_ID when NO directional WASD key remains held.
            // When opposing keys cancel out (e.g. W + S -> vx=0, vy=0), keep pointer 16 down at center.
            if (wasdPressedSet.isEmpty()) {
                if (wasDownBefore) {
                    isWasdDown = false
                    isWasdRampActive = false
                    shouldRelease = true
                }
            } else {
                val len = sqrt(vx * vx + vy * vy)
                if (len > 0f) {
                    vx /= len
                    vy /= len
                }
                wasdTargetX = (centerX + vx * radiusPx).coerceIn(2f, w - 2f)
                wasdTargetY = (centerY + vy * radiusPx).coerceIn(2f, h - 2f)
                if (!wasDownBefore) {
                    isWasdDown = true
                    isWasdRampActive = true
                    shouldStartRamp = true
                } else {
                    shouldMoveTarget = true
                }
            }
        }

        if (shouldRelease) {
            dispatchTouch {
                host.removeVirtualPointer(WASD_POINTER_ID)
            }
            return
        }

        if (shouldStartRamp) {
            dispatchTouch {
                val stillActive = synchronized(stateLock) { isWasdDown }
                if (!stillActive) return@dispatchTouch
                host.upsertVirtualPointer(WASD_POINTER_ID, centerX, centerY)
                safeSleepMs(4L)
                val midTarget = synchronized(stateLock) {
                    if (!isWasdDown) null
                    else ((centerX + wasdTargetX) * 0.5f).coerceIn(2f, w - 2f) to
                        ((centerY + wasdTargetY) * 0.5f).coerceIn(2f, h - 2f)
                } ?: return@dispatchTouch
                host.moveVirtualPointer(WASD_POINTER_ID, midTarget.first, midTarget.second)
                safeSleepMs(4L)
                val finalTarget = synchronized(stateLock) {
                    isWasdRampActive = false
                    if (!isWasdDown) null else wasdTargetX to wasdTargetY
                } ?: return@dispatchTouch
                host.moveVirtualPointer(WASD_POINTER_ID, finalTarget.first, finalTarget.second)
            }
        } else if (shouldMoveTarget) {
            dispatchTouch {
                val cur = synchronized(stateLock) {
                    if (!isWasdDown || isWasdRampActive) null else wasdTargetX to wasdTargetY
                }
                if (cur != null) {
                    host.moveVirtualPointer(WASD_POINTER_ID, cur.first, cur.second)
                }
            }
        }
    }

    private fun handleMouseDelta(dxRaw: Float, dyRaw: Float) {
        if (!injectionActive.get()) return
        if (!isAimLocked) return
        val cfg = config
        val hasMouseAim = cfg.nodes.any { it.type == KeymapActionType.MOUSE_AIM }
        val aimPanActiveNow = synchronized(stateLock) { isAimPanDown }
        if (!hasMouseAim && !aimPanActiveNow) return

        val shouldScheduleFlush: Boolean
        synchronized(stateLock) {
            pendingAimDx += dxRaw
            pendingAimDy += dyRaw
            shouldScheduleFlush = !aimFlushScheduled
            if (shouldScheduleFlush) {
                aimFlushScheduled = true
            }
        }
        if (shouldScheduleFlush) {
            val gen = aimGeneration.get()
            dispatchTouch { flushCoalescedMouseDelta(gen) }
        }
    }

    internal fun drainSmoothAimTickForTest() {
        flushCoalescedMouseDelta(aimGeneration.get(), isTailTick = true)
    }

    private fun flushCoalescedMouseDelta(expectedGeneration: Long, isTailTick: Boolean = false) {
        if (expectedGeneration != aimGeneration.get()) {
            synchronized(stateLock) { aimFlushScheduled = false }
            return
        }

        val dxRaw: Float
        val dyRaw: Float
        val hasResidual: Boolean
        synchronized(stateLock) {
            aimFlushScheduled = false
            dxRaw = pendingAimDx
            dyRaw = pendingAimDy
            pendingAimDx = 0f
            pendingAimDy = 0f
            hasResidual = smoothRemainX != 0f || smoothRemainY != 0f
        }

        if (!injectionActive.get()) return
        if (!isAimLocked) return
        val cfg = config
        val aimNode = cfg.nodes.firstOrNull { it.type == KeymapActionType.MOUSE_AIM }
        val aimPanActive = synchronized(stateLock) { isAimPanDown }
        if (aimNode == null && !aimPanActive) return

        val tweaks = cfg.tweaks
        val mag = hypot(dxRaw, dyRaw)
        val hasFreshMove = mag > 0f && mag >= tweaks.deadzonePx
        if (!hasFreshMove && !hasResidual) return

        val w = screenWidth.toFloat().coerceAtLeast(1f)
        val h = screenHeight.toFloat().coerceAtLeast(1f)
        val accelFactor = if (hasFreshMove && tweaks.acceleration > 0f) {
            1f + (tweaks.acceleration * (mag / 18f).coerceAtMost(2.5f))
        } else {
            1f
        }
        val rawScaledX = if (hasFreshMove) dxRaw * tweaks.sensitivityX * accelFactor else 0f
        val rawScaledY = if (hasFreshMove) dyRaw * tweaks.sensitivityY * accelFactor * (if (tweaks.invertY) -1f else 1f) else 0f

        var routeToAimPan = false
        var nextPanX = 0f
        var nextPanY = 0f
        var needInitialDown = false
        var needRecenter = false
        var centerX = 0f
        var centerY = 0f
        var nextX = 0f
        var nextY = 0f
        var scheduleTail = false

        synchronized(stateLock) {
            if (expectedGeneration != aimGeneration.get()) return
            smoothRemainX += rawScaledX
            smoothRemainY += rawScaledY

            val s = tweaks.smoothing.coerceIn(0f, 0.85f)
            val alpha = 1f - s
            var stepX = smoothRemainX * alpha
            var stepY = smoothRemainY * alpha
            smoothRemainX -= stepX
            smoothRemainY -= stepY

            // Snap tiny sub-pixel remainder so 100% of every slow micro-glide is preserved cleanly
            if (hypot(smoothRemainX, smoothRemainY) < 0.08f) {
                stepX += smoothRemainX
                stepY += smoothRemainY
                smoothRemainX = 0f
                smoothRemainY = 0f
            } else if (!runDirectInTests) {
                scheduleTail = true
            }

            if (stepX == 0f && stepY == 0f && (!isTailTick || !hasResidual)) {
                if (scheduleTail && !aimFlushScheduled) {
                    aimFlushScheduled = true
                    aimScheduler.schedule({
                        dispatchTouch { flushCoalescedMouseDelta(expectedGeneration, isTailTick = true) }
                    }, 6L, TimeUnit.MILLISECONDS)
                }
                return
            }

            if (isAimPanDown) {
                routeToAimPan = true
                aimPanCurX = (aimPanCurX + stepX).coerceIn(8f, w - 8f)
                aimPanCurY = (aimPanCurY + stepY).coerceIn(8f, h - 8f)
                nextPanX = aimPanCurX
                nextPanY = aimPanCurY
            } else if (aimNode != null) {
                centerX = (aimNode.xFraction * w).coerceIn(32f, w - 32f)
                centerY = (aimNode.yFraction * h).coerceIn(32f, h - 32f)
                val maxDriftPx = (tweaks.aimResetRadiusFraction * minOf(w, h)).coerceIn(60f, minOf(w, h) * 0.48f)

                if (!isAimDown) {
                    isAimDown = true
                    aimCurX = centerX
                    aimCurY = centerY
                    needInitialDown = true
                }

                nextX = aimCurX + stepX
                nextY = aimCurY + stepY

                val distFromCenter = hypot(nextX - centerX, nextY - centerY)
                if (distFromCenter > maxDriftPx ||
                    nextX < 16f || nextX > w - 16f ||
                    nextY < 16f || nextY > h - 16f
                ) {
                    needRecenter = true
                    aimCurX = (centerX + stepX).coerceIn(16f, w - 16f)
                    aimCurY = (centerY + stepY).coerceIn(16f, h - 16f)
                } else {
                    aimCurX = nextX
                    aimCurY = nextY
                }
                nextX = aimCurX
                nextY = aimCurY
            }

            if (scheduleTail && !aimFlushScheduled) {
                aimFlushScheduled = true
                aimScheduler.schedule({
                    dispatchTouch { flushCoalescedMouseDelta(expectedGeneration, isTailTick = true) }
                }, 6L, TimeUnit.MILLISECONDS)
            }
        }

        if (routeToAimPan) {
            host.moveVirtualPointer(AIM_PAN_POINTER_ID, nextPanX, nextPanY)
        } else if (aimNode != null) {
            if (needInitialDown) {
                host.upsertVirtualPointer(MOUSE_AIM_POINTER_ID, centerX, centerY)
                host.moveVirtualPointer(MOUSE_AIM_POINTER_ID, nextX, nextY)
            } else if (needRecenter) {
                host.removeVirtualPointer(MOUSE_AIM_POINTER_ID)
                safeSleepMs(1L)
                host.upsertVirtualPointer(MOUSE_AIM_POINTER_ID, centerX, centerY)
                host.moveVirtualPointer(MOUSE_AIM_POINTER_ID, nextX, nextY)
            } else {
                host.moveVirtualPointer(MOUSE_AIM_POINTER_ID, nextX, nextY)
            }
        }
    }

    private fun slotForNode(nodeId: String): Int {
        synchronized(stateLock) {
            return PointerStreamCoordinator.allocateSentuhSlot(nodeId, keyNodeToSlot)
        }
    }

    companion object {
        private const val TAG = "LvngKeymapEngine"
        const val AIM_PAN_INTERNAL_TWEAK = MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK
        const val MACRO_POINTER_ID = PointerStreamCoordinator.MACRO_POINTER_ID
        const val WASD_POINTER_ID = PointerStreamCoordinator.WASD_POINTER_ID
        const val MOUSE_AIM_POINTER_ID = PointerStreamCoordinator.MOUSE_AIM_POINTER_ID
        const val AIM_PAN_POINTER_ID = PointerStreamCoordinator.AIM_PAN_POINTER_ID
        const val KEY_SLOT_BASE = PointerStreamCoordinator.KEY_SLOT_BASE
        const val KEY_SLOT_COUNT = PointerStreamCoordinator.KEY_SLOT_COUNT

        private const val EV_SYN = 0
        private const val EV_KEY = 1
        private const val EV_REL = 2
        private const val SYN_REPORT = 0
        private const val REL_X = 0
        private const val REL_Y = 1
        private const val REL_WHEEL = 8
    }
}
