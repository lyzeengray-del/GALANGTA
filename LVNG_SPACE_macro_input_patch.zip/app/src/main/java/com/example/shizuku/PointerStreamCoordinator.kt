package com.example.shizuku

/**
 * Pure-Kotlin coordinator for Android Framework MotionEvent pointer streams.
 *
 * Layer separation:
 * - Linux kernel `ABS_MT_SLOT` exists solely inside `/dev/input/eventX` and is translated by
 *   Android's `InputReader` into `MotionEvent` physical `pointerId`s (typically `0..14`).
 * - This coordinator manages Framework `MotionEvent.PointerProperties.id` (`0..31`) only, never
 *   touching kernel `ABS_MT_SLOT`, and isolates virtual IDs cleanly from physical contacts:
 *   - `0..14` : Physical touchscreen contacts (observed via `InputMonitor`)
 *   - `15`    : Macro (`MACRO_POINTER_ID`)
 *   - `16`    : WASD Virtual Joystick (`WASD_POINTER_ID`)
 *   - `17`    : FPS Look (`MOUSE_AIM_POINTER_ID`)
 *   - `18`    : AimPan Fire+Drag (`AIM_PAN_POINTER_ID`)
 *   - `19..31`: Sentuh / Tap key nodes (`KEY_SLOT_BASE..MAX_VIRTUAL_POINTER_ID`)
 *
 * Non-preemption guarantees:
 * - Physical contacts are extracted from mixed monitor events; virtual IDs are ignored
 *   individually rather than causing the entire mixed event to be discarded.
 * - Solo `ACTION_DOWN` is NEVER emitted while any physical or virtual contact is active.
 * - Full `ACTION_UP` is emitted ONLY when `remainingTotal == 0` (last active pointer lifts).
 * - Releasing a single virtual button emits `ACTION_POINTER_UP` for that pointer index only.
 */
class PointerStreamCoordinator {

    data class PointerSnapshot(
        val id: Int,
        val x: Float,
        val y: Float,
        val pressure: Float = 1.0f,
        val size: Float = 0.08f,
        val touchMajor: Float = 12f,
        val touchMinor: Float = 12f,
        val toolType: Int = TOOL_TYPE_FINGER
    )

    data class PlannedMotionEvent(
        val downTime: Long,
        val eventTime: Long,
        val action: Int,
        val pointers: List<PointerSnapshot>,
        val deviceId: Int,
        val source: Int,
        val displayId: Int,
        val waitForResult: Boolean
    )

    sealed class UpsertPlan {
        data class JoinOrDown(
            val pointer: PointerSnapshot,
            val event: PlannedMotionEvent,
            val isFreshDown: Boolean
        ) : UpsertPlan()

        data class MoveExisting(
            val event: PlannedMotionEvent
        ) : UpsertPlan()
    }

    private val physicalPointers = LinkedHashMap<Int, PointerSnapshot>()
    private var physicalDownTime: Long = 0L
    private var physicalDeviceId: Int = 0
    private var physicalSource: Int = SOURCE_TOUCHSCREEN
    private var physicalDisplayId: Int = DEFAULT_DISPLAY

    private val virtualPointers = LinkedHashMap<Int, PointerSnapshot>()
    private var virtualGestureDownTime: Long = 0L
    private var lastEventTimeMs: Long = 0L

    var preferZeroDevIdForSolo: Boolean = false

    fun activePhysicalIds(): Set<Int> = physicalPointers.keys.toSet()

    fun activeVirtualIds(): Set<Int> = virtualPointers.keys.toSet()

    fun activePhysicalCount(): Int = physicalPointers.size

    fun activeVirtualCount(): Int = virtualPointers.size

    fun hasPhysicalContacts(): Boolean = physicalPointers.isNotEmpty()

    fun hasAnyActiveContact(): Boolean = physicalPointers.isNotEmpty() || virtualPointers.isNotEmpty()

    fun isVirtualActive(pointerId: Int): Boolean = virtualPointers.containsKey(pointerId)

    fun activeVirtualPointer(pointerId: Int): PointerSnapshot? = virtualPointers[pointerId]

    private fun monotonicEventTime(nowMs: Long, downTime: Long): Long {
        val safe = maxOf(nowMs, downTime, lastEventTimeMs)
        lastEventTimeMs = safe
        return safe
    }

    fun clearAll() {
        physicalPointers.clear()
        physicalDownTime = 0L
        virtualPointers.clear()
        virtualGestureDownTime = 0L
        lastEventTimeMs = 0L
    }

    fun clearPhysicalOnly() {
        physicalPointers.clear()
        physicalDownTime = 0L
    }

    fun onPhysicalEvent(
        actionMasked: Int,
        actionIndex: Int,
        downTime: Long,
        deviceId: Int,
        source: Int,
        displayId: Int,
        eventPointers: List<PointerSnapshot>
    ) {
        // InputMonitor can report a merged stream containing physical IDs (0..14) and
        // injected virtual IDs (15..31). Never discard the entire frame because it contains
        // a virtual pointer: doing so freezes the physical snapshot while a macro is held.
        // recordPhysicalPointers() below filters virtual IDs individually.
        val hasPhysical = eventPointers.any { it.id in 0..MAX_PHYSICAL_POINTER_ID }
        if (!hasPhysical) {
            // A terminal event with no physical pointers means the physical portion of the
            // monitored stream has ended. Virtual contacts are managed independently below.
            if (actionMasked == ACTION_UP || actionMasked == ACTION_CANCEL) {
                physicalPointers.clear()
                physicalDownTime = 0L
            }
            return
        }

        if (deviceId > 0) {
            physicalDeviceId = deviceId
        }
        if (source != 0) {
            physicalSource = source
        }
        if (displayId >= 0) {
            physicalDisplayId = displayId
        }

        when (actionMasked) {
            ACTION_DOWN -> {
                physicalPointers.clear()
                physicalDownTime = downTime
                recordPhysicalPointers(eventPointers)
            }

            ACTION_POINTER_DOWN, ACTION_MOVE -> {
                if (physicalPointers.isEmpty()) {
                    physicalDownTime = downTime
                }
                recordPhysicalPointers(eventPointers)
            }

            ACTION_POINTER_UP -> {
                recordPhysicalPointers(eventPointers)
                if (actionIndex in eventPointers.indices) {
                    val liftedId = eventPointers[actionIndex].id
                    if (liftedId in 0..MAX_PHYSICAL_POINTER_ID) {
                        physicalPointers.remove(liftedId)
                    }
                }
            }

            ACTION_UP, ACTION_CANCEL -> {
                physicalPointers.clear()
                physicalDownTime = 0L
                // Deliberately NEVER clear virtualPointers here: virtual joystick / buttons
                // remain alive until their owner explicitly releases them.
            }
        }
    }

    private fun recordPhysicalPointers(eventPointers: List<PointerSnapshot>) {
        for (p in eventPointers) {
            if (p.id < 0 || isVirtualPointerId(p.id)) continue
            physicalPointers[p.id] = p
        }
    }

    fun planUpsert(
        pointerId: Int,
        xPx: Float,
        yPx: Float,
        nowMs: Long,
        fallbackTouchDeviceId: Int,
        forcedSoloDeviceId: Int? = null
    ): UpsertPlan {
        if (virtualPointers.containsKey(pointerId)) {
            val moveEv = planMove(pointerId, xPx, yPx, nowMs, fallbackTouchDeviceId)
            if (moveEv != null) {
                return UpsertPlan.MoveExisting(moveEv)
            }
        }

        val safePtr = fingerPointer(pointerId, xPx, yPx)
        val hasPhys = physicalPointers.isNotEmpty() && physicalDownTime > 0L
        val hasVirt = virtualPointers.isNotEmpty()

        return if (hasPhys || hasVirt) {
            val resolvedDownTime = when {
                hasPhys -> physicalDownTime
                virtualGestureDownTime > 0L -> virtualGestureDownTime
                else -> nowMs
            }
            val combined = ArrayList<PointerSnapshot>(physicalPointers.size + virtualPointers.size + 1).apply {
                addAll(physicalPointers.values)
                addAll(virtualPointers.values)
                add(safePtr)
            }
            val newIdx = combined.size - 1
            val action = ACTION_POINTER_DOWN or (newIdx shl ACTION_POINTER_INDEX_SHIFT)
            val resolvedDevId = when {
                hasPhys -> if (physicalDeviceId > 0) physicalDeviceId else fallbackTouchDeviceId
                preferZeroDevIdForSolo -> 0
                physicalDeviceId > 0 -> physicalDeviceId
                else -> fallbackTouchDeviceId
            }
            val safeEventTime = monotonicEventTime(nowMs, resolvedDownTime)
            UpsertPlan.JoinOrDown(
                pointer = safePtr,
                event = PlannedMotionEvent(
                    downTime = resolvedDownTime,
                    eventTime = safeEventTime,
                    action = action,
                    pointers = combined,
                    deviceId = resolvedDevId,
                    source = physicalSource,
                    displayId = physicalDisplayId,
                    waitForResult = true
                ),
                isFreshDown = false
            )
        } else {
            val resolvedDevId = forcedSoloDeviceId
                ?: if (preferZeroDevIdForSolo) 0 else {
                    if (physicalDeviceId > 0) physicalDeviceId else fallbackTouchDeviceId
                }
            val safeEventTime = monotonicEventTime(nowMs, nowMs)
            UpsertPlan.JoinOrDown(
                pointer = safePtr,
                event = PlannedMotionEvent(
                    downTime = safeEventTime,
                    eventTime = safeEventTime,
                    action = ACTION_DOWN,
                    pointers = listOf(safePtr),
                    deviceId = resolvedDevId,
                    source = physicalSource,
                    displayId = physicalDisplayId,
                    waitForResult = true
                ),
                isFreshDown = true
            )
        }
    }

    fun commitUpsert(plan: UpsertPlan.JoinOrDown) {
        if (plan.isFreshDown) {
            virtualGestureDownTime = plan.event.downTime
        } else if (virtualGestureDownTime <= 0L) {
            virtualGestureDownTime = plan.event.downTime
        }
        virtualPointers[plan.pointer.id] = plan.pointer
    }

    fun planMove(
        pointerId: Int,
        xPx: Float,
        yPx: Float,
        nowMs: Long,
        fallbackTouchDeviceId: Int
    ): PlannedMotionEvent? {
        if (!virtualPointers.containsKey(pointerId)) return null
        virtualPointers[pointerId] = fingerPointer(pointerId, xPx, yPx)

        val hasPhys = physicalPointers.isNotEmpty() && physicalDownTime > 0L
        val combined = ArrayList<PointerSnapshot>(physicalPointers.size + virtualPointers.size).apply {
            addAll(physicalPointers.values)
            addAll(virtualPointers.values)
        }
        if (combined.isEmpty()) return null

        val downTime = when {
            hasPhys -> physicalDownTime
            virtualGestureDownTime > 0L -> virtualGestureDownTime
            else -> nowMs
        }
        if (virtualGestureDownTime <= 0L) {
            virtualGestureDownTime = downTime
        }
        val devId = when {
            hasPhys -> if (physicalDeviceId > 0) physicalDeviceId else fallbackTouchDeviceId
            preferZeroDevIdForSolo -> 0
            physicalDeviceId > 0 -> physicalDeviceId
            else -> fallbackTouchDeviceId
        }
        return PlannedMotionEvent(
            downTime = downTime,
            eventTime = monotonicEventTime(nowMs, downTime),
            action = ACTION_MOVE,
            pointers = combined,
            deviceId = devId,
            source = physicalSource,
            displayId = physicalDisplayId,
            waitForResult = false
        )
    }

    fun planRemove(
        pointerId: Int,
        nowMs: Long,
        fallbackTouchDeviceId: Int
    ): PlannedMotionEvent? {
        if (!virtualPointers.containsKey(pointerId)) return null

        val hasPhys = physicalPointers.isNotEmpty() && physicalDownTime > 0L
        val combined = ArrayList<PointerSnapshot>(physicalPointers.size + virtualPointers.size).apply {
            addAll(physicalPointers.values)
            addAll(virtualPointers.values)
        }
        val idx = combined.indexOfFirst { it.id == pointerId }
        if (idx < 0 || combined.isEmpty()) return null

        val downTime = when {
            hasPhys -> physicalDownTime
            virtualGestureDownTime > 0L -> virtualGestureDownTime
            else -> nowMs
        }
        val devId = when {
            hasPhys -> if (physicalDeviceId > 0) physicalDeviceId else fallbackTouchDeviceId
            preferZeroDevIdForSolo -> 0
            physicalDeviceId > 0 -> physicalDeviceId
            else -> fallbackTouchDeviceId
        }

        // Full ACTION_UP is ONLY emitted when 0 contacts remain in the entire stream!
        val action = if (combined.size == 1) {
            ACTION_UP
        } else {
            ACTION_POINTER_UP or (idx shl ACTION_POINTER_INDEX_SHIFT)
        }

        return PlannedMotionEvent(
            downTime = downTime,
            eventTime = monotonicEventTime(nowMs, downTime),
            action = action,
            pointers = combined,
            deviceId = devId,
            source = physicalSource,
            displayId = physicalDisplayId,
            waitForResult = true
        )
    }

    fun commitRemove(pointerId: Int) {
        virtualPointers.remove(pointerId)
        if (virtualPointers.isEmpty()) {
            virtualGestureDownTime = 0L
        }
    }

    fun removeVirtual(
        pointerId: Int,
        nowMs: Long,
        fallbackTouchDeviceId: Int
    ): PlannedMotionEvent? {
        val planned = planRemove(pointerId, nowMs, fallbackTouchDeviceId)
        commitRemove(pointerId)
        return planned
    }

    companion object {
        const val MAX_PHYSICAL_POINTER_ID = 14
        const val MACRO_POINTER_ID = 15
        const val WASD_POINTER_ID = 16
        const val MOUSE_AIM_POINTER_ID = 17
        const val AIM_PAN_POINTER_ID = 18
        const val KEY_SLOT_BASE = 19
        const val MAX_VIRTUAL_POINTER_ID = 31
        const val KEY_SLOT_COUNT = (MAX_VIRTUAL_POINTER_ID - KEY_SLOT_BASE) + 1 // 13 slots: 19..31

        const val ACTION_DOWN = 0
        const val ACTION_UP = 1
        const val ACTION_MOVE = 2
        const val ACTION_CANCEL = 3
        const val ACTION_POINTER_DOWN = 5
        const val ACTION_POINTER_UP = 6
        const val ACTION_POINTER_INDEX_SHIFT = 8

        const val TOOL_TYPE_FINGER = 1
        const val SOURCE_TOUCHSCREEN = 0x00001002
        const val DEFAULT_DISPLAY = 0

        fun isVirtualPointerId(pid: Int): Boolean =
            pid in MACRO_POINTER_ID..MAX_VIRTUAL_POINTER_ID

        fun fingerPointer(id: Int, xPx: Float, yPx: Float): PointerSnapshot {
            return PointerSnapshot(
                id = id,
                x = xPx.coerceAtLeast(0f),
                y = yPx.coerceAtLeast(0f),
                pressure = 1.0f,
                size = 0.08f,
                touchMajor = 12f,
                touchMinor = 12f,
                toolType = TOOL_TYPE_FINGER
            )
        }

        fun allocateSentuhSlot(
            nodeId: String,
            assignedMap: MutableMap<String, Int>,
            reservedIds: Set<Int> = emptySet()
        ): Int {
            assignedMap[nodeId]?.let { existing ->
                if (existing in KEY_SLOT_BASE..MAX_VIRTUAL_POINTER_ID) return existing
            }
            val used = HashSet<Int>(assignedMap.values).apply { addAll(reservedIds) }
            for (slot in KEY_SLOT_BASE..MAX_VIRTUAL_POINTER_ID) {
                if (!used.contains(slot)) {
                    assignedMap[nodeId] = slot
                    return slot
                }
            }
            val wrapped = KEY_SLOT_BASE + (assignedMap.size % KEY_SLOT_COUNT)
            assignedMap[nodeId] = wrapped
            return wrapped
        }
    }
}
