package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.LvngCrimson
import com.example.ui.theme.LvngCrimsonBright
import com.example.ui.theme.LvngTextPrimary
import com.example.ui.theme.LvngVoid
import com.example.ui.theme.RajdhaniFontFamily
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LvngStartupSplashOverlay(
    visible: Boolean,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val emblemScale = remember { Animatable(0.84f) }
    val emblemAlpha = remember { Animatable(0f) }
    val glowAlpha = remember { Animatable(0f) }
    val sheenProgress = remember { Animatable(-0.6f) }
    val textSlideY = remember { Animatable(14f) }
    val textAlpha = remember { Animatable(0f) }
    val bootProgress = remember { Animatable(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "lvng_orbit")
    val haloAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "halo_angle"
    )

    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        coroutineScope {
            launch {
                emblemAlpha.animateTo(1f, tween(340, easing = FastOutSlowInEasing))
            }
            launch {
                emblemScale.animateTo(
                    targetValue = 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                )
            }
            launch {
                glowAlpha.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
            }
            launch {
                delay(240L)
                sheenProgress.animateTo(1.6f, tween(620, easing = FastOutSlowInEasing))
            }
            launch {
                delay(160L)
                launch { textAlpha.animateTo(1f, tween(340, easing = FastOutSlowInEasing)) }
                launch { textSlideY.animateTo(0f, tween(380, easing = FastOutSlowInEasing)) }
            }
            launch {
                delay(120L)
                bootProgress.animateTo(1f, tween(1150, easing = FastOutSlowInEasing))
            }
        }
        delay(140L)
        onFinished()
    }

    AnimatedVisibility(
        visible = visible,
        exit = fadeOut(tween(280)) + scaleOut(targetScale = 1.03f, animationSpec = tween(280)),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF1A070B),
                            Color(0xFF0B0608),
                            LvngVoid
                        )
                    )
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onFinished
                )
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("lvng_startup_splash")
        ) {
            // Subtle atmospheric crimson bloom + restrained precision arc behind the emblem
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width * 0.5f
                val cy = size.height * 0.45f
                val bloomRadius = size.minDimension * 0.44f

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            LvngCrimson.copy(alpha = 0.22f * glowAlpha.value),
                            Color.Transparent
                        ),
                        center = Offset(cx, cy),
                        radius = bloomRadius
                    ),
                    radius = bloomRadius,
                    center = Offset(cx, cy)
                )

                val orbitR = 76.dp.toPx() * emblemScale.value
                rotate(degrees = haloAngle, pivot = Offset(cx, cy)) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            0.0f to Color.Transparent,
                            0.42f to LvngCrimsonBright.copy(alpha = 0.52f * emblemAlpha.value),
                            0.65f to Color.Transparent
                        ),
                        startAngle = 0f,
                        sweepAngle = 210f,
                        useCenter = false,
                        topLeft = Offset(cx - orbitR, cy - orbitR),
                        size = Size(orbitR * 2f, orbitR * 2f),
                        style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 32.dp)
            ) {
                // Sleek squircle logo badge using actual LVNG SPACE logo + subtle metallic light sweep
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(116.dp)
                        .scale(emblemScale.value)
                        .alpha(emblemAlpha.value)
                        .clip(RoundedCornerShape(30.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF220B10),
                                    Color(0xFF10080A)
                                )
                            )
                        )
                        .border(
                            width = 1.2.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.22f),
                                    LvngCrimsonBright.copy(alpha = 0.55f),
                                    Color.White.copy(alpha = 0.08f)
                                )
                            ),
                            shape = RoundedCornerShape(30.dp)
                        )
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.lvng_space_logo),
                        contentDescription = "LVNG SPACE",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(30.dp))
                    )

                    // Diagonal specular sheen sweep once on entrance
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val p = sheenProgress.value
                        if (p in -0.55f..1.55f) {
                            val startX = size.width * p
                            drawLine(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.White.copy(alpha = 0.22f),
                                        Color.Transparent
                                    ),
                                    start = Offset(startX - size.width * 0.28f, 0f),
                                    end = Offset(startX + size.width * 0.28f, size.height)
                                ),
                                start = Offset(startX - size.width * 0.12f, -12f),
                                end = Offset(startX + size.width * 0.12f, size.height + 12f),
                                strokeWidth = size.width * 0.26f
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(26.dp))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .graphicsLayer {
                            alpha = textAlpha.value
                            translationY = textSlideY.value
                        }
                ) {
                    Text(
                        text = "LVNG SPACE",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        letterSpacing = 5.sp,
                        color = LvngTextPrimary
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Minimal hairline loader bar
                    Box(
                        modifier = Modifier
                            .width(136.dp)
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xFF211317))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(bootProgress.value.coerceIn(0f, 1f))
                                .height(2.5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(LvngCrimson, LvngCrimsonBright)
                                    )
                                )
                        )
                    }
                }
            }
        }
    }
}
